import * as database from './projectdb.js';

database.getAllDocs();