import express from "express";
import * as database from "./projectdb.js";
import bodyParser from "body-parser";
import _ from "lodash";
import cors from "cors";

const app = express();

const corsOptions = {
  origin: "*",
  methods: [],
  allowedHeaders: [],
  exposedHeaders: [],
  credentials: true,
};

const port = 3000;
app.use(bodyParser.json());

let myProjectName = "Project-Alpha";
let projectTree = [];
let projectNodes = [];
let projArr = [];
let treeData;
let myProject;
let debug = false;

//-----------------------------------------------------------------------------------
async function refreshProject(projectname) {
  let resp = await database.findDocument(projectname, database.PROJECT);
  if (resp !== null) {
    myProject = resp.docs[0];

    console.log(resp);

    await processChildren(myProject);

    treeData = transformToTree(projArr);
    if (debug) {
      console.log(JSON.stringify(treeData, null, 2));
    }
  } else {
    console.log("Database " + myProjectName + " failed to load");
  }
}

//-----------------------------------------------------------------------------------
await refreshProject(myProjectName);

//await database.closeDatabase();   move to exit app function

//-----------------------------------------------------------------------------------
// recursively loads the tree
async function processChildren(doc) {
  if (doc !== null) {
    console.log("------------------------------------------------- ");
    console.log(
      "Processing " + doc.name + "\n\t id: " + doc._id + "\n\trev: " + doc._rev
    );
    console.log(doc);

    let children = await database.getChildren(doc._id);
    if (doc.type == "result") {
      projArr.push({
        id: doc._id,
        rev: doc._rev,
        parent: doc.parent,
        name: doc.name,
        type: doc.type,
        ancestors: doc.ancestors,
        status: doc.status,
        measType: doc.measType,
        testTime: doc.testTime,
        device: doc.device,
        serialNo: doc.serialNo,
      });
    } else {
      projArr.push({
        id: doc._id,
        rev: doc._rev,
        parent: doc.parent,
        name: doc.name,
        type: doc.type,
        ancestors: doc.ancestors,
      });
    }
    if (children.docs.length == 0) {
      console.log("no children to process");
      return;
    }
    for (const element of children.docs) {
      // build up the ancetors path
      let path = "";
      for (const ansid of element.ancestors) {
        let ans = await database.getDocumentId(ansid, null);
        path = path.concat(ans.name + " | ");
      }
      console.log("------------------------------------------------- ");
      console.log("Path: " + path + " " + element.name);
      await processChildren(element);
    }
  } else {
    console.log("Database " + myProjectName + " failed to load");
  }
}

//-----------------------------------------------------------------------------------
function transformToTree(arr) {
  let nodes = {};
  return arr.filter(function (obj) {
    let id = obj["id"],
      parentId = obj["parent"];

    nodes[id] = _.defaults(obj, nodes[id], { children: [] });
    nodes[parentId] = nodes[parentId] || { children: [] };

    parentId && nodes[parentId]["children"].push(obj);

    return !parentId;
  });
}

//-----------------------------------------------------------------------------------
// Helper functions
//-----------------------------------------------------------------------------------
// validate project object name has no illegal characters and is within the max length req

//-----------------------------------------------------------------------------------
// API Endpoints
//-----------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------
// GENERAL
//-----------------------------------------------------------------------------------
// get a document ancestor path for breadcrumbs  - requires a document id, returns an array of objects  { id, name, alias, type}

// rename a document - requires a document id
// verify the name meets name requirement
// requires additional processing if the document is a project
// delete project document - requires document id
// database.deleteDoc( "76dc72be-8394-407e-943f-699f99f33356" );

//-----------------------------------------------------------------------------------
// PROJECT
//-----------------------------------------------------------------------------------
app.get("/api/v1/projects", cors(corsOptions), (req, res) => {
  refreshProject(myProjectName)
    .then((response) => {
      console.log(`Received response refreshProject: ${response}`);
    })
    .catch((response) => {
      console.log("Received Error refreshProject: $(response)");
    });
  // get the list of projects
  let list = [
    { name: "Project-0001", isActive: true },
    { name: "project-0002", isActive: false },
    { name: "project-0003", isActive: true },
  ];

  console.log("get list of projects");
  res.send(list);
});

//-----------------------------------------------------------------------------------
app.get("/api/v1/project/:name", cors(corsOptions), (req, res) => {
  // verify project name
  // use the name to get to the correct database
  console.log("get project called " + req.params.name);
  res.send(treeData);
});

//-----------------------------------------------------------------------------------
app.post("/api/v1/project", cors(corsOptions), (req, res) => {
  // use the name to get to the correct database
  let data = req.body;
  let resp = "New Project Created: " + data.name;
  console.log(resp);
  console.log(req.body);
  res.send(resp);
});

//-----------------------------------------------------------------------------------
app.delete("/api/v1/project/:name", cors(corsOptions), (req, res) => {
  console.log("delete  project:  " + req.params.name);

  //close this database and delete the folder on disk

  res.send(req.params.name);
});

//-----------------------------------------------------------------------------------
app.patch("/api/v1/project/:name", cors(corsOptions), (req, res) => {
  console.log("rename project id  " + req.params.name);

  //get the old name from the paramters or body

  let resp = "Update Project: " + data.name;
  console.log(resp);
  console.log(req.body);
  res.send(resp);
});

//-----------------------------------------------------------------------------------
// FOLDER
//-----------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------
app.get(
  "/api/v1/project/:name/folder/:folderId",
  cors(corsOptions),
  (req, res) => {
    // verify project name & folder

    let resp =
      "get project called " +
      req.params.name +
      " folder Id: " +
      req.params.folderId;
    console.log(resp);
    database
      .getDocumentId(req.params.folderId, res)
      .then((response) => {
        console.log(`Received response getDocumentId: ${response}`);
      })
      .catch((response) => {
        console.log("Received Error getDocumentId: $(response)");
      });
  }
);

//-----------------------------------------------------------------------------------
app.post("/api/v1/project/:name/folder", cors(corsOptions), (req, res) => {
  // use the name to get to the correct database
  let data = req.body;
  let resp =
    "New Folder Created: " + data.name + " in project " + req.params.name;
  console.log(resp);

  database
    .addProjectFolder(data.name, myProject._id, res)
    .then((response) => {
      console.log(`Received response addProjectFolder: ${response}`);
    })
    .catch((response) => {
      console.log("Received Error addProjectFolder: $(response)");
    });
});

//-----------------------------------------------------------------------------------
app.delete("/api/v1/project/:name/folder", cors(corsOptions), (req, res) => {
  let resp = "delete  folder: " + req.body;
  console.log(resp);

  database
    .deleteDocIdRev(req.body, res)
    .then((response) => {
      console.log(`Received response: ${response}`);
    })
    .catch((response) => {
      console.log("Received Error: $(response)");
    });
});

//-----------------------------------------------------------------------------------
app.patch("/api/v1/project/:name/folder", cors(corsOptions), (req, res) => {
  let resp =
    "patch  folder:  " + req.body._id + " from project " + req.body._rev;
  console.log(resp);

  //get the old name from the paramters or body
  database
    .updateDocument(req.body, res)
    .then((response) => {
      console.log(`Received response updateDocument: ${response}`);
    })
    .catch((response) => {
      console.log("Received Error updateDocument: $(response)");
    });
});

//-----------------------------------------------------------------------------------
// RESULTS
//-----------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------
app.get(
  "/api/vi/project/:name/folder/:folderid/results",
  cors(corsOptions),
  (req, res) => {
    // verify project name & folder

    database
      .getChildren(req.params.folderid, res)
      .then((response) => {
        console.log(`getResults ${response}`);
      })
      .catch((response) => {
        console.log("Received Error getDocument: $(response)");
      });
  }
);

//-----------------------------------------------------------------------------------
app.post("/api/v1/project/:name/folder/:folderid/results", cors(corsOptions), (req, res) => {
  // use the name to get to the correct database
  let data = req.body;
  let resp =
    "new results added to project " +
    req.params.name +
    " folder id " +
    req.params.folderid;

  console.log(resp);
  console.log(data);
  res.send(resp);
});

//-----------------------------------------------------------------------------------
app.delete(
  "/api/v1/project/:name/folder/:folderId/results/:resultId",
  cors(corsOptions),
  (req, res) => {
    let resp =
      "delete  results:  " +
      req.params.resultId +
      " from folder " +
      req.params.folderId +
      " in project " +
      req.params.name;
    console.log(resp);

    res.send(resp);
  }
);

//PATCH api/v1 /project/<project name>/folder/<id>/results   ???? probably will not need this endpoint

//-----------------------------------------------------------------------------------
app.get(
  "/api/v1/project/:name/folder/:folderId/result/:resultId/attachments",
  cors(corsOptions),
  (req, res) => {
    // verify project name & folder
    // get a list of attachments
    let resp =
      "get attachment list from result " +
      req.params.name +
      " folder id " +
      req.params.folderId +
      " result id " +
      req.params.resultId;

    console.log(resp);
    res.send(resp);
  }
);

//GET api/v1 /project/<project name>/result/{resultId}/attachment/{index}
//POST api/v1 /project/<project name>/result/{resultId}/attachment
//DELETE api/v1 /project/<project name>/result/{resultId}/attachment/{index}

//-----------------------------------------------------------------------------------
app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});

//-----------------------------------------------------------------------------------
function getDatabase(name) {
  return database;
}

//-----------------------------------------------------------------------------------
function validateDocumentName(name) {
  return true;
}
