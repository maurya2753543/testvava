import * as database from './projectdb.js';

let projectName = 'Project-Alpha';
let folderNames = [ 'Job-01', 'Job-02', 'Job-03'];
let resultNames = [ 'Result-X', 'Result-Y', 'Result-Z'];


await database.destroyDB();
database.newDatabase();


// add a project
console.log( "Create Project ");
let project = await database.createProject( projectName);
if ( project !== null ) {

    console.log( project );
    
    folderNames.forEach( async function( element ) { 

        console.log( "Create Folders " + element );
        let fldr = await database.addProjectFolder( element, project.id, null );
        if( fldr !== null ) {

            console.log( fldr );
            let folder = await database.getDocumentId( fldr.id, null );

            resultNames.forEach( async function( resultElement ) { 

                
                let result = await database.addResultFile( resultElement, folder );
                if( result !== null ) {
                        console.log( result );

                } else {
                    console.log( "Result add failed at folder id: " + folder._id );
                }

            });

        } 
        else {
            console.log( "Folder add failed for project id: " + project.is);
        }
    });

    
} else {
    console.log( "Something went wrong created the database");
}


