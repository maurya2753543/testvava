import PouchDB from "pouchdb";
import PouchFind from "pouchdb-find";
import path from 'path';


PouchDB.plugin(PouchFind);

export const PROJECT = "project";
export const FOLDER = "folder";
export const RESULT = "result";

let dbName = "sample_projectdb";
let dbPath = "database";

let filePath = path.join( dbPath, dbName  );

//let db = new PouchDB("./database/my_projectdb");
//let db = new PouchDB("./database/sample_projectdb");
let db = new PouchDB ( filePath );
let cfg = new PouchDB("./database/config-2");

// import truePon_data from "./sample-results/truePON.json" assert { type: "json" };
// import opticalloss_data from "./sample-results/2023-03-22T15-20-57.wfl-20230327140050.json" assert { type: "json" };

export function newDatabase() {

    db = new PouchDB("./database/sample_projectdb");
    console.log("----------------------------------------------------");
    console.log("-- New Database Created");
    console.log("----------------------------------------------------");
    
}



 //---------------------------------------------------------
 export async function closeDatabase() {
 console.log("Closing databases");
 await db.close();
 await cfg.close();

 console.log("Done");
}

//---------------------------------------------------------
export function getAllDatabaseInfo() {
  db.info()
    .then(function (result) {
      console.log("-- Project Info -----------------------------------------");
      console.log(result);
    })
    .catch(function (err) {
      console.log(err);
    });

  cfg
    .info()
    .then(function (result) {
      console.log("-- Config Info -----------------------------------------");
      console.log(result);
    })
    .catch(function (err) {
      console.log(err);
    });


}

//---------------------------------------------------------
export async function destroyDB(myDb) {
    try {
        let response = await db.destroy() 
        console.log("DB-destroyed: " + response); // success
    } catch (err) {
      console.log(err);
    }
}

//---------------------------------------------------------
export async function deleteDocIdRev( folder, func ) {

    try {
        let response = await db.remove( folder._id, folder._rev )
        if( func != null ) { func.send( response ); };
        console.log( response );
    } catch (err) {
        console.log( "remove failed " + err )
    }


}


//---------------------------------------------------------
export async function deleteDocId( id, func ) {

    try {
        let response = await db.remove( id )
        if( func != null ) { func.send( response ); };
        console.log( response );
    } catch (err) {
        console.log( "remove failed " + err )
    }


}

//---------------------------------------------------------
export async function updateDocument( doc, func ) {

    try {
        let document = await db.get(doc._id);

        console.log( doc );
        console.log( document );
        // apply the updates here

        document.name = doc.name;

        // then put the doucment backin the database

        let response = await db.put({
          _id: doc._id,
          _rev: doc._rev,
          name: doc.name
        });

        if( func != null ) { func.send( response ); };
      } catch (err) {
        console.log(err);
      }
}


//---------------------------------------------------------
export async function createIndex() {
  await db
    .createIndex({
      index: { fields: ["name"] },
    })
    .then(function (doc) {
      console.log(doc);
    });
}

//---------------------------------------------------------
export async function getChildren(id, func) {
  try {
    let response = await db.find({
      selector: {
        parent: { $eq: id },
      },
    });
    if( func != null ) { func.send( response );}
    else { return response } ;
    
  } catch (err) {
    console.log(err);
  }
  
}

//---------------------------------------------------------
export async function findDocument(name, type) {
  
  try {
      let response = await db.find({
      selector: {
        name: { $eq: name },
        type: { $eq: type },
      },
    }

    );
    return response;
  } catch (err) {
    console.log(err);
  }
  
}


//---------------------------------------------------------
export async function getDocumentId(id, func ) {
    try {
        let response = await db.get( id, {attachments: true});
        if( func != null ) { func.send( response ); };
        return( response );
    } catch (err) {
      console.log(err);
      return err;
    }

  }
  



//---------------------------------------------------------
export async function createProject(name) {
  let project = {
    ancestors: [],
    parent: null,
    name: name,
    type: PROJECT,
  };
  try {
    let result = await db.post(project); 
    //console.log(result);
    return result;
  } catch (err) {
    console.log(err);
  }
}

//---------------------------------------------------------
export async function addProjectFolder(name, parent_Id, func) {
  //get the parent_id
  //console.log("Add folder " + name + " | " + parent_Id );
  let folder = {
    name: name,
    ancestors: [parent_Id],
    parent: parent_Id,
    type: FOLDER,
  };
  try {
    let response = await db.post( folder );
    if( func != null ) { func.send( response ); };
    return( response );
} catch (err) {
  console.log(err);
  return err;
}


}

//---------------------------------------------------------
export async function addResultFile(name, parent) {

    
 
  let myAncestors = [...parent.ancestors];
  myAncestors.push(parent._id);

  // extract the KPIs and add to the result document   (This may be the same a columns)
  // gather columns and add
  // gather attachment and add attachment

  let myResult = {
    name: name,
    ancestors: myAncestors,
    parent: parent._id,
    type: RESULT,
    measType: "truepon",                                        // Todo:   replace with passed in data
    testTime: "2023-04-14T0:26:51-04:00",
    status: "pass",
    location: "Location Label DEF",
    limit: "default",
    device: "OLP-39V2",
    serialNo: "2336-02-A-0151",
  };

  try {
    let result = await db.post(myResult);
        console.log(result);
        return( result );
  
  } catch(err) {
    console.log(err);
  }
}

//---------------------------------------------------------
async function addAttachment(id, rev, attachmentId, attachment, format) {
  // application/json

  try {
    let result = await db.putAttachment(
      id,
      attachmentId,
      rev,
      attachment,
      "application/json"
    );
    return result;
  } catch (err) {
    console.log(err);
  }
  console.log( result );
}


//---------------------------------------------------------
async function getAttachment(id, attachmentId) {
    
  
    try {
      let attach = await db.getAttachment(
        id,
        attachmentId
      );

        let str = attach.toString().replaceAll("\\" , "");
        let obj = JSON.parse( str );


      console.log( JSON.stringify( obj, null, 2) );
      return obj;
    } catch (err) {
      console.log(err);
    }
    
  }

//---------------------------------------------------------
async function deleteAttachment(rev, attachmentId) {
    // application/json
  
    try {
      let result = await db.putAttachment(
        rev,
        attachmentId
      );
      console.log( results );
      return results;
    } catch (err) {
      console.log(err);
    }
    console.log( result );
  }
 

//--- TEST FUNCTION ------------------------------------------------------
export async function getAllDocs(limit) {
  let t1 = new Date();
  await db.allDocs({ include_docs: true, descending: true }, function (err, doc) {
    let t2 = new Date();
    console.log("-- All Docs ------------------------------");
    console.log("records: " + doc.total_rows);
    console.log(doc.rows);
    console.log( "Elapsed Time: " + (t2 - t1) + ' mS');
  });
}


