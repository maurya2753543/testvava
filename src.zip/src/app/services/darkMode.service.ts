import { Injectable, Renderer2, RendererFactory2, EventEmitter } from "@angular/core";
import { Subject } from "rxjs";
@Injectable({
    providedIn: 'root'
})

export class DarkModeService{
    private renderer: Renderer2;
    private isDarkMode = false;

    constructor(private rendererFactory: RendererFactory2){
        this.renderer = rendererFactory.createRenderer(null,null);
    }

    toggleDarkMode():void{
        this.isDarkMode = !this.isDarkMode;
        if(this.isDarkMode){
            this.renderer.addClass(document.body,'dark-mode');
        } else{
            this.renderer.removeClass(document.body,'dark-mode');
        }
    }
    // I add for recieved dark themes event
    DarkThemeEvent = new EventEmitter();
    emitEvent() {
      this.DarkThemeEvent.emit();
    }


    isDarkModeEnabled(): boolean {
        return this.isDarkMode;
    }


    private isDarkThemesActiveSubject = new Subject<string>();
    isDarkThemesActiveSubject$ = this.isDarkThemesActiveSubject.asObservable();
      
    isDarkThemesActiveValue(value: string) {
        this.isDarkThemesActiveSubject.next(value);
      }
}
