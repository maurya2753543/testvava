import { Injectable } from '@angular/core'
import {Subject} from 'rxjs'

export interface RefreshArea {
  multiSegmentLine?: true
}
@Injectable({
  providedIn: 'root'
})
export class LayoutService {

  public refreshLayout$ = new Subject<RefreshArea | undefined>()

  constructor() { }

  public refreshLayout(area?: RefreshArea){
    this.refreshLayout$.next(area)
  }
}
