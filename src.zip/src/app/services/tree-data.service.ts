import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
/**
 * Node for to-do item
 */
export class TodoItemNode {
  children: TodoItemNode[] = []
  name: string;
  id: string;
  rev: string;
  parent: string;
  projectId: string
}

/** Flat to-do item node with expandable and level information */
export class TodoItemFlatNode {
  name: string;
  level: number;
  expandable: boolean;
  children: any;
  id: string;
  rev: string;
  parent: string;
  projectId: string
}

/**
 * The Json object for to-do list data.
 */

@Injectable({
  providedIn: 'root'
})
export class TreeDataService {



  dataChange = new BehaviorSubject<TodoItemNode[]>([]);

  get data(): TodoItemNode[] {
    console.log('this.dataChange.value', this.dataChange.value);
    return this.dataChange.value;
  }

  constructor(private http: HttpClient) {
    this.initialize();
  }

  public getProjectList(): Observable<any> {
    return this.http.get('http://localhost:3000/api/v1/projects');
  }

  public getProjectChildren(): Observable<any> {


    return this.http.get('http://localhost:3000/api/v1/project');
  }

  public createProject(message: string): Observable<any> {

    const url = 'http://localhost:3000/api/v1/project';
    const body = { name: message };
    return this.http.post<any>(url, body);

  }


  public deleteProject(message: any): Observable<any> {
    const body = { name: message.name, _id: message.id, _rev: message.rev };


    const httpOptions = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' }), body: body
    };
    const url = 'http://localhost:3000/api/v1/project';

    return this.http.delete(url, httpOptions);


  }

  public addFolderProject(parentId: string, projectId: string, name: string): Observable<any> {
    const url = 'http://localhost:3000/api/v1/project/folder';
    const body = { name: name, projectId: projectId, parentId: parentId };
    return this.http.post(url, body);
  }

  initialize(incomeData?: any) {
    this.getProjectChildren().subscribe((treeData: any) => {
      const data = this.buildFileTree([treeData], 0);
      // Notify the change.
      this.dataChange.next(data);
    })

  }

  /**
   * Build the file structure tree. The `value` is the Json object, or a sub-tree of a Json object.
   * The return value is the list of `TodoItemNode`.
   */
  buildFileTree(obj: any, level: number): TodoItemNode[] {
    return Object.keys(obj).reduce<TodoItemNode[]>((accumulator, key) => {
      const value = obj[key];
      return accumulator.concat(obj[key]);
    }, []);
  }


  /** Add an item to to-do list */
  insertItem(parent: TodoItemNode, name: string) {
    if (parent.children) {
      parent.children.push({ name: name } as TodoItemNode);
      this.dataChange.next(this.data);
    }
  }

  removeInsert(activeNode: any) {
    if (activeNode.children && Array.isArray(activeNode.children)) {
      activeNode.children.forEach((child: any, index: number) => {
        if (child.name === "") {
          activeNode.children.splice(index, 1);
          this.dataChange.next(this.data);
        }
      });
    }
  }

  updateItem(node: TodoItemNode, name: any, parentId: string, projectId: string, id: string) {
    node.name = Object.keys(name)[0];
    node.children = [];
    node.projectId = projectId;
    node.parent = parentId;
    node.id = id;
    this.dataChange.next(this.data);
  }

}
