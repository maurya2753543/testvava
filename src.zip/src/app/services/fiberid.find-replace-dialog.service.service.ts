import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FiberIdFindReplaceDialogComponent } from '../components/fiber-id-find-replace-dialog/fiber-id-find-replace-dialog.component';

@Injectable({
  providedIn: 'root'
})
export class FiberidFindReplaceDialogServiceService {
  constructor(private dialog: MatDialog) { }

  openDialog(data: any) {
    const dialogRef = this.dialog.open(FiberIdFindReplaceDialogComponent, {
      //  maxHeight: '500px',
      data: data
    });
  }
}
