import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, timestamp } from 'rxjs';

interface TestResultRow {
    Timestamp: string;
    Test: string;
    Location: string;
    Status: string;
    Limit: string;
    device: string;
    id: number;
}

interface DataSet {
    project: string;
    id: number;
    parentId: number;
    timestamp: string;
    testType: string;
    location: string;
    status: string;
    limit: string;
    device: string;

}


interface Project {
    name: string;
    activeNode: any;
    pathToActiveNode: number[];
    columnsCfg: ColumnConfiguration[];
    levelAliases: string[];
}

interface Node {
    id: number;
    name: string;
    chidren: Node[];
    treeLevel: number;
}

interface ColumnConfiguration {
    width: number;
    isVisible: boolean;
    orderIndex: number;
}

interface TestColumn {
    name: string;
    type: string;     // number, string,
    numDigits: 2;
    cdmPath: string;
}

@Injectable({
  providedIn: 'root'
})
export class ProjectsService {


    constructor(private http: HttpClient) {

     }

    rowData: TestResultRow [] = [];

    // Project management
    newProject() {}
    save() {}
    open() {}
    export() {}
    import() {}

    // general node
    getActiveNode(): Node  {
        var node = <Node>{ id: 1, name: "myNode", chidren: [], treeLevel: 1};
        return node;
    }

    getActiveNodeId() : number { return 1}

    setActiveNodeId( id: number) { }

    addChild( child: Node ) {}
    deleteChild( id: number ) {}
    deleteNode( id :  number) {}

    // results




    getProjectData() {

        let testType = 'Inspection';
        let loc = 'Location A';
        let statusVal = 'PASS';
        let limit = 'Default'
        let device = 'p5000i';

        for( var id = 1; id <= 250; id++) {

            let timestampStr = new Date ( Date.now());

            if( id % 3 ) { statusVal = 'PASS' } else { statusVal = 'FAIL'} ;
            if( id % 2 ) { loc = 'Location A' } else { loc = 'Location B'} ;
            if( id % 9 ) { device = 'p5000i' } else { device = 'FiberCheckProbe'} ;
            if( id % 7 ) {  } else { device = 'Corvus'} ;

            var row: TestResultRow = {
                Timestamp: timestampStr.toISOString(),
                Test: testType,
                Location: loc,
                Status: statusVal,
                Limit: limit,
                device: device,
                id: id
            };
            this.rowData.push( row );


        }


        this.rowData[2].Test = 'Optical Loss'
        this.rowData[3].Test = 'TruePON'
        this.rowData[4].Test = 'OTDR'
        this.rowData[5].Test = 'Optical Power'
        return this.rowData


    }

// make update service



    // getLineChart() {
    //     return
    // }

    public getLineChart(): Observable<any> {
        return this.http.get("./assets/cable02-data.json");
    }

    public getOTDRTrace(): Observable<any> {

        return this.http.get("./assets/otdr-01.json");
    }


    getProjectsTree() {

        return  [

            {"name" : "subProject X",
                    "children" : [
                        {"name" : "SBX-"}
                    ]},

                { "name" : "subProject Y",
                "children" : [
                    {"name" : "SBY-"}
                ]},

                { "name" : "subProject Z",
                "children" : [
                    {"name" : "SBZ-1", "children" : [
                        {"name" : "SBZ-2", "children" : [
                            {"name" : "SBZ-3", "children" : [
                                {"name" : "SBZ-4","children" : [
                                    {"name" : "SBZ-5", "children" : [
                                        {"name" : "SBZ-6", "children" : [
                                            {"name" : "SBZ-7", "children" : [
                                                {"name" : "SBZ-8", "children" : [
                                                    {"name" : "SBZ-9", "children" : [
                                                        {"name" : "SBZ-10",  iconname: 'folder'}]} ]} ]} ]} ]} ]} ]}  ]} ]}
                ]},

              {name: 'Project Alpha',
              children: [{name: 'Cable 1-A', iconname: 'folder'},
                         {name: 'Cable 1-B', iconname: 'folder'},
                         {name: 'Rack 2', children: [{name: 'Cable 1-B', iconname: 'folder'}]},
                         {name: 'Cable 1-C', iconname: 'folder'}]
            },
            {
              name: 'Project Beta',
              children: [
                {
                  name: 'Floor 1',
                  children: [{name: 'Room 1', iconname:'folder'}, {name: 'Room 2' , iconname:'folder'}],
                },
                {
                  name: 'Floor 2',
                  children: [{name: 'Server Room', iconname: 'folder'}, {name: 'Router Room', iconname: 'folder'}],
                },
              ],
            },
          ];

    }


    public getOtdr(): Observable<any> {
        return this.http.get("./assets/otdr-01.json");
    }

    public getFiberInspectionLoss():Observable<any> {
        
        return this.http.get("./assets/fiber-inspection-01.json");
    }
 
   public getProjectList():Observable<any> {
    return this.http.get('http://localhost:3000/api/v1/projects');
   }

   public getColumnsTable() {

    
        let resp =  [
            { "name" : "Common Columns", 
              "children": [        
                    { "name" : "Timestamp", "header" : "Timestamp", "type" : "ISOdateTime", "cdmPath" : "tests.results.testTime"  },
                    { "name" : "Test Type", "header" : "Test", "type" : "string", "cdmPath" : "tests.label"  },
                    { "name" : "Locaion", "header" : "ID", "type" : "string", "cdmPath" : "tests.testLocations.label"  },
                    { "name" : "Status", "header" : "Status", "type" : "status", "cdmPath" : "tests.results.status"  },
                    { "name" : "Device", "header" : "Device", "type" : "string", "cdmPath" : "assetInfo.model"  }
                ]
            },
            { "name" : "Fiber Inspection", 
                "children" : [
                { "name" : "Measurement",  
                    "children" :  [
                        { "name": "ZoneA", "header" : "Zone A", "type": "status", "cdmPath" : "tests.result.data.status" },
                        { "name": "ZoneB", "header" : "Zone B", "type": "status", "cdmPath" : "tests.result.data.status" },
                        { "name": "ZoneC", "header" : "Zone C", "type": "status", "cdmPath" : "tests.result.data.status" },
                        { "name": "ZoneD", "header" : "Zone D", "type": "status", "cdmPath" : "tests.result.data.status" },
                        { "name": "ZoneE", "header" : "Zone E", "type": "status", "cdmPath" : "tests.result.data.status" },
                        { "name": "ZoneF", "header" : "Zone F", "type": "status", "cdmPath" : "tests.result.data.status" },
                        { "name": "ZonePassAll", "header" : "passAll", "type": "status", "cdmPath" : "tests.result.data.status" },
                        { "name": "ZonePassDefects", "header" : "Zone Pass Defects", "type": "status", "cdmPath" : "tests.result.data.status" },
                        { "name": "ZonePassScratches", "header" : "Zone Pass Scratches", "type": "status", "cdmPath" : "tests.result.data.status" }
                    ],
                },
                { "name" : "Configuration", "children" : [ {"name" : "Threshold"}]},
                { "name" : "Insturment", "children" : [{"name" : "Software Version"}]}
        
                ]   
            },
            { "name" : "Optical Loss", 
                "children" : [
                { "name" : "Measurement",  
                    "children" :  [
                    { "name": "Wavelength", "header" : "Wavelength", "type": "number", "cdmPath" : "tests.result.data.wavelength" },
                    { "name": "Insertion Loss", "header" : "Insertion Loss", "type": "number", "cdmPath" : "tests.result.data.wavelength" },
                    { "name": "Reference", "header" : "Reference", "type": "number", "cdmPath" : "tests.result.data.wavelength" }
                    ],
                },
                { "name" : "Configuration", "children" : [ {"name" : "Threshold"}]},
                { "name" : "Insturment", "children" : [{"name" : "Software Version"}]}
            ]
            }
        ];

        return resp;

   }

}
