import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TestDetailService {
  
  constructor(private http: HttpClient) { }
  getData() {
    return [
    {"assetInfo": {

      "assetType": "OLP-39V2",
  
      "model": "OLP-39X",
  
      "uniqueId": "2336-02-A-0151",
  
      "serialNo": "2336-02-A-0151",
  
      "calibrationDate": "2022-08-10",
  
      "swVersion": "03.02.00-dev.2",
  
      "hwVersion": "2336-7001.923R01, Rev.004, D51",
  
      "techId": "",
      "modulesInfo": [
        {
          "assetType": "T-BERD/MTS module",
          "uniqueId": "4136 MA3FCO_00535",
          "model": "4136 MA3FCO",
          "calibrationDate": "2018-04-23",
          "swVersion": ""
        }
      ]
  
    } }
  ]
  }

  getMeasurementData() {
    return [  {"tests": [

      {
  
        "description": "TruePON Test",
  
        "label": "TruePON Test",
  
        "schemaVersion": "2.0.0",
  
        "type": "truepon",
  
        "configuration": {
  
          "alarmsMode": "passfail",
  
          "signalSetup": "gpon;xgspon",
  
          "ponLocation": "ont",
  
          "ponLocationLabel": "ONT",
  
          "gpon": {
  
            "odnClassSetup": "auto",
  
            "oltIdFormat": "hex",
  
            "limits": [
  
              {
  
                "odnClass": "b+",
  
                "lossLimitLower": 13,
  
                "lossLimitUpper": 28.5,
  
                "powerDownstreamLimitLower": -27,
  
                "powerDownstreamLimitUpper": -8
  
              }
  
            ]
  
          },
  
          "xgspon": {
  
            "odnClassSetup": "auto",
  
            "oltIdFormat": "hex",
  
            "limits": [
  
              {
  
                "odnClass": "n1",
  
                "lossLimitLower": 18,
  
                "lossLimitUpper": 33,
  
                "powerDownstreamLimitLower": -28,
  
                "powerDownstreamLimitUpper": -9
  
              }
  
            ]
  
          }
  
        },
  
        "results": {
  
          "status": "fail",
  
          "testTime": "2021-01-03T01:14:48-04:00",
  
          "data": {
  
            "gpon": {
  
              "loss": 14.72,
  
              "lossMarginLower": 1.72,
  
              "lossMarginUpper": 13.78,
  
              "lossTestStatus": "pass",
  
              "oltId": [48, 47, 50, 47, 49, 0, 0],
  
              "odnClass": "b+",
  
              "odnClassTestStatus": "pass",
  
              "tol": 5.7,
  
              "powerDownstream": -9.02,
  
              "powerDownstreamMarginLower": 17.98,
  
              "powerDownstreamMarginUpper": 1.02,
  
              "powerDownstreamSignalStatus": "ok",
  
              "powerDownstreamTestStatus": "pass"
  
            },
  
            "xgspon": {
  
              "loss": 15.02,
  
              "lossMarginLower": -2.98,
  
              "lossMarginUpper": 17.98,
  
              "lossTestStatus": "fail",
  
              "oltId": [48, 47, 50, 47],
  
              "odnClass": "n1",
  
              "odnClassTestStatus": "pass",
  
              "tol": 6,
  
              "powerDownstream": -7.76,
  
              "powerDownstreamMarginLower": 20.24,
  
              "powerDownstreamMarginUpper": -1.24,
  
              "powerDownstreamSignalStatus": "ok",
  
              "powerDownstreamTestStatus": "fail"
  
            }
  
          }
  
        },
        "assetInfo": {

          "assetType": "OLP-39V2",
      
          "model": "OLP-39X",
      
          "uniqueId": "2336-02-A-0151",
      
          "serialNo": "2336-02-A-0151",
      
          "calibrationDate": "2022-08-10",
      
          "swVersion": "03.02.00-dev.2",
      
          "hwVersion": "2336-7001.923R01, Rev.004, D51",
      
          "techId": "",
          "modulesInfo": [
            {
              "assetType": "T-BERD/MTS module",
              "uniqueId": "4136 MA3FCO_00535",
              "model": "4136 MA3FCO",
              "calibrationDate": "2018-04-23",
              "swVersion": ""
            }
          ]
      
        } 
      }
  
    ]}]
  }

}
