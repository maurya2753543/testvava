import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject ,timestamp} from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
export interface selectedSize {
  gridSize: number;
  detailSize: number;
}

interface TestResultRow {
  Timestamp: string;
  Test: string;
  Location: string;
  Status: string;
  Limit: string;
  device: string;
  id: number;
}

@Injectable({
  providedIn: 'root'
})
export class SharedService {

  constructor(private http: HttpClient) {

  }

 rowData: TestResultRow [] = [];
  private subject = new Subject<any>();
  private selectedData: any[] = [];

  setSelectedData(data: any[]) {
    this.selectedData = data;
  }
  getSelectedData(): any[] {
    return this.selectedData;
  }

  sendClickEvent(event: any) {
    this.subject.next(event);
  }

  getClickEvent(): Observable<any> {
    return this.subject.asObservable();
  }

  /////////////Vertical and Horizontal View ///////////////
  private selectedViewDirection = new Subject<any>();

  getselectedViewDirection() {
    return this.selectedViewDirection.asObservable();
  }

  setselectedViewDirection(value: any) {
    this.selectedViewDirection.next(value);
  }

  private data = new Subject<string>();

  setData(value: string) {
    this.data.next(value);
  }

  getData() {
    return this.data.asObservable();
  }

  columnDefs = new Subject<any>();


  private gridApi: any;

  setGridApi(gridApi: any) {
    this.gridApi = gridApi;
  }

  getGridApi() {
    return this.gridApi;
  }

  // private columnDefs = new Subject<any>();

  getColumnDefinations() {
    return this.columnDefs;
  }

  setColumnDefincation(columnDefs: any) {
    this.columnDefs = columnDefs;
  }
// import service data hire

// making Import services in the ng -grid update data

private importFileDataSubject = new Subject<string>();
importFileDataSubjectNext$ = this.importFileDataSubject.asObservable();
 setImportFileData(value: any) {
   this.importFileDataSubject.next(value);
 }




  //////////////Previous and next selection from detail tab to grid ///////////////
  private valuePrevNextSubject = new Subject<string>();
  valuePrevNext$ = this.valuePrevNextSubject.asObservable();

  setPreNextValue(value: string) {
    this.valuePrevNextSubject.next(value);
  }

  //////////////set Size value on split area when expand and collapse ///////////////
  private valueSizeSubject = new Subject<selectedSize>();
  valueSize$ = this.valueSizeSubject.asObservable();

  setSizetValue(value: selectedSize) {
    this.valueSizeSubject.next(value);
  }


    //////////////Breadcrumbs obj and tree node id  ///////////////

    private valueBreadcrumbsSubject = new Subject<any>();
    valueBreadcrumbsSubject$ = this.valueBreadcrumbsSubject.asObservable();
    setBreadcrumbsValue(value: any) {
      this.valueBreadcrumbsSubject.next(value);
    }


    private valueIdSubject = new Subject<object>();
    valueidSubject$ = this.valueIdSubject.asObservable();
    setIdValue(value: string, nodeClicked: boolean) {
      this.valueIdSubject.next({value: value, nodeClicked: nodeClicked});
    }
      

    /////////////////////////////////////////////

  isVisibleSource: BehaviorSubject<boolean> = new BehaviorSubject(false);


}
