import { DataSource } from '@angular/cdk/collections';
import { Component, OnInit } from '@angular/core';
import { ProjectsService } from 'src/app/services/projects.service';

@Component({
  selector: 'app-events-table',
  templateUrl: './events-table.component.html',
  styleUrls: ['./events-table.component.scss']
})
export class EventsTableComponent implements OnInit {
  dataSource: any
  constructor(private projectService: ProjectsService) {

  }
  ngOnInit() {
    this.projectService.getOtdr().subscribe((data: any) => {
      const eventData = data.tests[0].results.data.otdrResults.measuredResults[0].events;
      const updateEvents = []


      for (let i = 0; i < eventData.length; i++) {
        const event = eventData[i];
        
        if (i > 0) {

          updateEvents.push({ ...eventData[i], length: eventData[i].distance - eventData[i - 1].distance });
        } else {

          updateEvents.push({ ...eventData[i], length: eventData[i].distance });
        }
      }
      this.dataSource = updateEvents;
      
    })
    console.log('dataSource', this.dataSource)
  }

  displayedColumns: string[] = ['eventTestStatus', 'id', 'eventType', 'distance', 'length', 'lossdB', 'reflectancedB'];
}
