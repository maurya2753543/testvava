import { Component, Input  } from '@angular/core';
// import jsPDF from 'jspdf';
// import html2canvas from 'html2canvas';
import { SharedService } from 'src/app/services/shared.service';
import {MatDialog} from '@angular/material/dialog';
import { FiberidFindReplaceDialogServiceService } from '../../services/fiberid.find-replace-dialog.service.service'; 
import {
    faFileChartColumn,
    faFileExport,
    faFloppyDisk,
    faFloppyDiskPen,
    faFolderOpen,
    faImage,
    faQuestion,
    faXmarkCircle,
    faCloudArrowDown,
    faPenToSquare,
    faUsbDrive,
    faFileImport,
    faEllipsis,
    faTruckMoving,
    faTrash
   
  } from '@fortawesome/pro-solid-svg-icons'
  export interface DialogData {
    animal: string;
    name: string;
  }

@Component({
  selector: 'app-test-toolbar-panel',
  templateUrl: './test-toolbar-panel.component.html',
  styleUrls: ['./test-toolbar-panel.component.scss']
})
export class TestToolbarPanelComponent {

    faFolderOpen = faFolderOpen
    faFloppyDisk = faFloppyDisk
    faFloppyDiskPen = faFloppyDiskPen
    faFileExport = faFileExport
    faFileChartColumn = faFileChartColumn
    faHelpQuestion = faQuestion
    faImage = faImage
    faXMark = faXmarkCircle
    faEllipsis = faEllipsis

    faCloudArrowDown = faCloudArrowDown
    faPenToSquare = faPenToSquare
    faUsbDrive = faUsbDrive
    faFileImport = faFileImport

    faTruckMoving = faTruckMoving
    faTrash = faTrash
    animal: string | undefined;
    name: string | undefined;

    @Input() selectedRows: any;

    updateData(selectedRows: any) {
      this.selectedRows = selectedRows;
    }
    
    constructor( private sharedService: SharedService, public dialog: MatDialog, private FiberidFindReplaceDialogServiceService: FiberidFindReplaceDialogServiceService) {

    }

    exportToCSV(event:any) {
        console.log( "exportToCSV" )
        this.sharedService.sendClickEvent(event)
    }


    exportToPDF(event:any) {

        console.log( "clicked export to PDF")
        let DATA: any = document.getElementById('main-grid');
        let PATH: any = document.getElementById('project-path');
        
    // html2canvas(DATA).then((canvas) => {
    //   let fileWidth = 208;
    //   let fileHeight = (canvas.height * fileWidth) / canvas.width;
    //   const FILEURI = canvas.toDataURL('image/png');
    //   let PDF = new jsPDF('p', 'mm', 'a4');
    //   let position = 20;
      
    //   PDF.text("V-Reporter - Project Ed", 10, 10)
    //   PDF.line( 10, 15, fileWidth-10, 15)
    //   PDF.addImage(FILEURI, 'PNG', 10, position, fileWidth - position, fileHeight);
    //   PDF.save('angular-demo.pdf');
    // }); 
    }

    // editFiberId() {
    //   // debugger

    //   (click)="openDialog()"
    // }

    // openeditFiberIdDialog


    openeditFiberIdDialog(): void {  
      // dialogRef.afterClosed().subscribe(result => {
      //   console.log('The dialog was closed');
      //   this.animal = result;
      // });

      // this.FiberidFindReplaceDialogServiceService.openDialog();
      this.FiberidFindReplaceDialogServiceService.openDialog(this.selectedRows);
  
      // dialogRef.afterClosed().subscribe(result => {
      //   console.log(`Dialog result: ${result}`);
      // });
    }

    
}


