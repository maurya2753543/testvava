import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestToolbarPanelComponent } from './test-toolbar-panel.component';

describe('TestToolbarPanelComponent', () => {
  let component: TestToolbarPanelComponent;
  let fixture: ComponentFixture<TestToolbarPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestToolbarPanelComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestToolbarPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
