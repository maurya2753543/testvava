import { Component, HostBinding, Inject, OnInit } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SharedService } from 'src/app/services/shared.service';
import { faTableRows } from '@fortawesome/pro-solid-svg-icons';
import { DarkModeService } from 'src/app/services/darkMode.service';
import { OverlayContainer } from '@angular/cdk/overlay';
import { FormControl } from '@angular/forms';

export interface DialogData {
  version: any;
}

@Component({
  selector: 'app-menu-bar',
  templateUrl: './menu-bar.component.html',
  styleUrls: ['./menu-bar.component.scss'],
})
export class MenuBarComponent implements OnInit {

  DarkThemesApply :any
  constructor(public dialog: MatDialog,  private sharedService: SharedService,
     private darkModeService: DarkModeService, private overlay: OverlayContainer) {





  }
  public toggle :any = false;
  @HostBinding('class') className = '';

  toggleControl = new FormControl(false);
  ngOnInit(): void {
    this.darkModeService.emitEvent();
    //this.toggleDarkMode(event: Event);
  }
   theme(value: string) {
    if (value) {
      document.getElementsByTagName('body')[0].classList.add(value);
    } else {
      document.getElementsByTagName('body')[0].classList.remove('dark-theme');
    }
    this.#theme = value;
  }
  #theme: string = '';


  // selectedView: string;
 selectedFile: File;
 faTableRows = faTableRows

  itemcclickEventlick() {
    console.log($localize`click New event`);
  }

  saveProject() {
    console.log($localize`click save event`);
  }

  saveAs() {
    console.log($localize`click Save as event`);
  }

  closeClick() {
    console.log($localize`click Close event`);
  }

  CloseAllClick() {
    console.log($localize`click Close all event`);
  }


  settingClick() {
    console.log($localize`click Setting event`);
  }

  helpAboutClicked() {
    this.dialog.open(HelpAboutDialog, {
      data: {
        version: $localize`0.1`,
      },
    });
  }

  doFileInput(event:  Event) {
    const element = event.currentTarget as HTMLInputElement;
    let fileList: FileList | null = element.files;
    if (fileList) {
      console.log($localize`FileUpload -> files`, $localize`${fileList}`);
    }
  }

 toggleView (event: Event) {
  const element = event.currentTarget as HTMLInputElement;
  console.log(element.getAttribute('val'));
  this.sharedService.setselectedViewDirection(element.getAttribute('val'));
  //  selectedView = element.getAttribute('val')
 }



 /////// imported json file reads into obj//////////

 onFileSelected(event: Event) {
  const input = event.target as HTMLInputElement;
  if (input && input.files && input.files.length) {
    this.selectedFile = input.files[0];
    const reader = new FileReader();

    reader.onload = (e) => {
      const result = reader.result;
      const jsonObject = result ? JSON.parse(result.toString()): [];
      console.log(jsonObject);
      // debugger
    };

    reader.readAsText(this.selectedFile);
  }
}
toggleDarkMode(event: Event): void {


  this.darkModeService.emitEvent();
  if (this.#theme === 'dark-theme') {
    this.#theme = '';
  } else {
    this.#theme = 'dark-theme';
  }
  this.theme(this.#theme);
  this.darkModeService.isDarkThemesActiveValue(this.#theme);
  // localStorage.setItem('toggle',this.toggle)
  // console.log("Clicked on themes",this.toggle);
  // this.darkModeService.toggleDarkMode();
}
public isDark:any = false ;

// toggleDarkMode(): void {

//   this.isDark = !this.isDark;
//   console.log(this.isDark);
//   localStorage.setItem('isDrak',this.isDark)
// }

}

@Component({
  selector: 'help-about-dialog',
  templateUrl: 'help-about-dialog.html',
})
export class HelpAboutDialog {
  constructor(@Inject(MAT_DIALOG_DATA) public data: DialogData) {}
}
