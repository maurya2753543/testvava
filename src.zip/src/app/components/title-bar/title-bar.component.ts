import { Component , OnInit} from '@angular/core';
import { faBook, faQuestionCircle } from "@fortawesome/free-solid-svg-icons"
import { DarkModeService } from 'src/app/services/darkMode.service';

@Component({
  selector: 'app-title-bar',
  templateUrl: './title-bar.component.html',
  styleUrls: ['./title-bar.component.scss']
})
export class TitleBarComponent implements OnInit {
    faBook = faBook
    faQuestionCircle = faQuestionCircle
    //isDarkThemes logic
   DarkThemesApply :any
    constructor(private DarkModeService: DarkModeService) {


     }
     ngOnInit() {


      this.DarkModeService.isDarkThemesActiveSubject$.subscribe(value => {
        this.DarkThemesApply=value

      })
    }



}
