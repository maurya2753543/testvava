import { Component } from '@angular/core';

export interface ResultTableData1 {
  wavelength?: string;
  power?: string;
  status: string;
}
const TABBLE1_DATA: ResultTableData1[] = [
  {wavelength: '1490', status: 'FAIL'},
  {wavelength: '1577', power: '-11.02', status: 'PASS'},
];

export interface ResultTableData2 {
  wavelength?: string;
  low?: string;
  lowMarginal: string;
  highMarginal: string;
  high: string
}
const TABBLE2_DATA: ResultTableData2[] = [
  {wavelength: '1490', low: '-33', lowMarginal: '1', highMarginal: '0', high: '13'},
  {wavelength: '1577', low: '-33', lowMarginal: '1', highMarginal: '0', high: '13'}
];

@Component({
  selector: 'app-test-detail-measurement-result-optical-power',
  templateUrl: './test-detail-measurement-result-optical-power.component.html',
  styleUrls: ['./test-detail-measurement-result-optical-power.component.scss']
})
export class TestDetailMeasurementResultOpticalPowerComponent {
  displayedColumns1: string[] = ['wavelength', 'power', 'status'];
  dataSource1 = TABBLE1_DATA;
  
  displayedColumns2: string[] = ['wavelength', 'low', 'lowMarginal', 'highMarginal', 'high'];
  dataSource2 = TABBLE2_DATA;

}
