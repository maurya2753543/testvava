import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestDetailMeasurementResultOpticalPowerComponent } from './test-detail-measurement-result-optical-power.component';

describe('TestDetailMeasurementResultOpticalPowerComponent', () => {
  let component: TestDetailMeasurementResultOpticalPowerComponent;
  let fixture: ComponentFixture<TestDetailMeasurementResultOpticalPowerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestDetailMeasurementResultOpticalPowerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestDetailMeasurementResultOpticalPowerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
