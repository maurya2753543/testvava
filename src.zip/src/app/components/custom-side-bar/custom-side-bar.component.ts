import { Component,Output,EventEmitter, OnInit, ViewChild } from '@angular/core';
import { SharedService } from 'src/app/services/shared.service';
import { ProjectsService } from 'src/app/services/projects.service';
import { TestGridPanelComponent } from '../test-grid-panel/test-grid-panel.component';
import {MatTreeNestedDataSource, MatTreeModule} from '@angular/material/tree';
import {NestedTreeControl} from '@angular/cdk/tree';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatButtonModule} from '@angular/material/button';


interface ColumnNode {
    name: string;
    children?: ColumnNode[];
  }
@Component({
  selector: 'app-custom-side-bar',
  templateUrl: './custom-side-bar.component.html',
  styleUrls: ['./custom-side-bar.component.scss']
})
export class CustomSideBarComponent implements OnInit {
  @ViewChild('TestGridPanelComponent')
  filterGrid!: TestGridPanelComponent;

  treeControl = new NestedTreeControl<ColumnNode>(node => node.children);
  dataSource = new MatTreeNestedDataSource<ColumnNode>();
  checklistSelection = true;

  todoItemSelectionToggle(node: any): void {
    console.log("todoItemSelectionToggle", node);
}

  constructor(private SharedService: SharedService, private ProjectsService: ProjectsService, private TestGridPanelComponent: TestGridPanelComponent) {
     this.columnDefs = this.SharedService.getColumnDefinations();
 // debugger
    // this.SharedService.getColumnDefs().subscribe(value => {
    //   this.columnDefs = value;
    // });

    //this.dataSource.data = this.TREE_DATA;
  }

  hasChild = (_: number, node: ColumnNode) => !!node.children && node.children.length > 0;

//   columnsTree : ColumnNode = [];
//  TREE_DATA: ColumnNode[] = []

    
  

  ngOnInit() {
    // debugger
    // this.SharedService.getColumnDefs().subscribe(newValue => {
    //   console.log('New value:', newValue);
    //   // do something with the new value
    //   // debugger
    // });

    this.fetchData()

    this.SharedService.isVisibleSource.subscribe((isVisible) => {
      console.log('isVisible: ', isVisible); // => true/false
    });

    

  }

  private async fetchData(){

    //console.log("fetch Columns Tree");
    let resp  = this.ProjectsService.getColumnsTable();

     //this.TREE_DATA = resp;
     this.dataSource.data = resp;

    //console.log("fetch return", this.TREE_DATA);
  }

  
@Output() toggleColumnVisibility = new EventEmitter<string>();
columnDefs: any
// private gridApi: any;
columns = [
  {name:'TimeStamp',field:'TimeStamp',visible: true},
  {name:'Test Type',field:'Test',visible: true},
  {name:'Device',field:'device',visible: true}
];

  /////////////////////Custom Hide and Show Coulumns in ag-grid///////////////////////

  onToggleColumnVisibility(columnsFiled: string) {
    // Set the colField value to match
    const colField = columnsFiled;

    // Find the column definition object with the matching field property
   const colDef = this.columnDefs.find((def: { field: string; }) => def.field === colField);


    // Update the hide property of the matching column definition object
    if (colDef) {
      colDef.hide = !colDef.hide; // Or false to show the column
       const gridApi = this.SharedService.getGridApi();
        gridApi.setColumnDefs(this.columnDefs);  
    }

  }

  onCheckBoxClicked(columnsFiled: any) {
    this.onToggleColumnVisibility(columnsFiled);
  }
// updatecheckBoxListData(columnDefs: any) {
//   // debugger
//   this.columnDefs = columnDefs;
 
// }

}
