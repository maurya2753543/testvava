import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomSideBarComponent } from './custom-side-bar.component';

describe('CustomSideBarComponent', () => {
  let component: CustomSideBarComponent;
  let fixture: ComponentFixture<CustomSideBarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomSideBarComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomSideBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
