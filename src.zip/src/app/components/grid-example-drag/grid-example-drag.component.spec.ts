import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GridExampleDragComponent } from './grid-example-drag.component';

describe('GridExampleDragComponent', () => {
  let component: GridExampleDragComponent;
  let fixture: ComponentFixture<GridExampleDragComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GridExampleDragComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GridExampleDragComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
