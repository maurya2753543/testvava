import { Component,Output, Input, OnInit, ViewChild ,EventEmitter } from '@angular/core';
import { SharedService } from 'src/app/services/shared.service';
import { TestToolbarPanelComponent } from '../test-toolbar-panel/test-toolbar-panel.component';
import { TestGridPanelComponent } from '../test-grid-panel/test-grid-panel.component';
import { TestDetailTabsComponent  } from '../test-detail-tabs/test-detail-tabs.component';
import {ProjectInfoPanelComponent} from '../project-info-panel/project-info-panel.component'
import { Subscription, retry } from 'rxjs';
import { DarkModeService } from 'src/app/services/darkMode.service';

@Component({
  selector: 'app-project-panel',
  templateUrl: './project-panel.component.html',
  styleUrls: ['./project-panel.component.scss']
})
export class ProjectPanelComponent implements OnInit{



  selectedViewDirection: any = 'vertical';
  @ViewChild(TestGridPanelComponent) child1: TestGridPanelComponent | undefined;
  @ViewChild(TestToolbarPanelComponent)
  child2!: TestToolbarPanelComponent;
  @ViewChild(TestDetailTabsComponent) detailTabChild!: TestDetailTabsComponent;
  @ViewChild(ProjectInfoPanelComponent) projecDataUpdate!: ProjectInfoPanelComponent;
  splitAreaSize1 = 50;
  splitAreaSize2 = 50;
   //isDarkThemes logic
   DarkThemesApply :any

// For Dark mode variable


  constructor( private sharedService: SharedService ,  public darkModeService: DarkModeService ) {

    this.darkModeService.isDarkThemesActiveSubject$.subscribe(value => {
      this.DarkThemesApply=value

    })
    this.sharedService.getselectedViewDirection().subscribe(value => {
      this.selectedViewDirection = value;
    });
   }
  ngOnInit(): void {

    this.sharedService.valueSize$.subscribe(value => {
      this.splitAreaSize1 = value.gridSize;
      this.splitAreaSize2 =  value.detailSize;
        // Handle the value update in the grand-grand-grandparent component
      });
}
  @Input() splitAreaSize: any;
     ProjectRow: any;
     childData: any;
     rowData: any










   onChildEvent(event: any) {

    this.darkModeService.isDarkThemesActiveSubject$.subscribe(value => {
      this.DarkThemesApply=value

    })
     this.childData = event;
    //  this.child2.updateData(event);
   }
   onRowChildEvent(event: any) {

    this.darkModeService.isDarkThemesActiveSubject$.subscribe(value => {
      this.DarkThemesApply=value

    })
    // this.ProjectRow=this.projecDataUpdate.ProjectData.rowData;

    // console.log(this.ProjectRow , "++++++++++++== Update data in side project panel  this.ProjectRow")
    this.rowData = event;
    this.detailTabChild.updateRowData(event)

//this.projecDataUpdate.updateRowDataProject(event)
   }

}


