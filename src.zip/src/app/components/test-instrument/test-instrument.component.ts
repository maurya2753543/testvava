import { Component, Input, OnInit } from '@angular/core';
import { TestDetailService } from 'src/app/services/test-detail.service';

export interface ResultTableData {
  name?: string;
  description?: string;
  type: string;
  expireDate: string
}
const TABBLE1_DATA: ResultTableData[] = [
  { name: 'TPA', description: 'Test Process Automation', type: 'SW Permanent', expireDate: 'n/a' },
  { name: 'Turbo', description: 'Turbo Processor', type: 'HW', expireDate: 'n/a' }
];

@Component({
  selector: 'app-test-instrument',
  templateUrl: './test-instrument.component.html',
  styleUrls: ['./test-instrument.component.scss']
})
export class TestInstrumentComponent implements OnInit {

  myData: any;
  @Input() DarkThemesApply: string | undefined;
  //isDarkThemesActive: boolean = false;

  constructor(private TestDetailService: TestDetailService) {
   }
  ngOnInit(): void {
    this.myData = this.TestDetailService.getData()
  }

  displayedColumns: string[] = ['name', 'description', 'type', 'expireDate'];
  dataSource = TABBLE1_DATA;

  uppercaseValue(word: any) {

    const result = word.replace(/[A-Z]/g, ' $&');
    return result[0].toUpperCase() + result.substr(1);
  }
}
