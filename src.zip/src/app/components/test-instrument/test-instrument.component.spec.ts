import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestInstrumentComponent } from './test-instrument.component';

describe('TestInstrumentComponent', () => {
  let component: TestInstrumentComponent;
  let fixture: ComponentFixture<TestInstrumentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestInstrumentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestInstrumentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
