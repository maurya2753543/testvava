import { Component, EventEmitter, Output , OnInit } from '@angular/core';
import { TreeDataService } from 'src/app/services/tree-data.service';
import {
    faPlus,
    faFileImport,
    faEllipsis,
    faFloppyDisk,
    faFloppyDiskPen,
    faEdit,
    faFileExport,
    faClose
  } from '@fortawesome/pro-solid-svg-icons'
  import { DarkModeService } from 'src/app/services/darkMode.service';

@Component({
  selector: 'app-project-nav-toolbar',
  templateUrl: './project-nav-toolbar.component.html',
  styleUrls: ['./project-nav-toolbar.component.scss']
})
export class ProjectNavToolbarComponent implements OnInit {
  @Output() messageEvent = new EventEmitter<string>();
    faPlus = faPlus
    faFileImport = faFileImport
    faEllipsis = faEllipsis
    faFloppyDisk = faFloppyDisk
    faFloppyDiskPen = faFloppyDiskPen
    faEdit = faEdit;
    faFileExport = faFileExport
    faClose = faClose;
    // Dark themes
    DarkThemesApply :any

    constructor(private TreeDataService: TreeDataService ,  public darkModeService: DarkModeService) {

    }

    ngOnInit(): void {
      this.darkModeService.isDarkThemesActiveSubject$.subscribe(value => {
        this.DarkThemesApply=value

      })
    }

    sendMessage() {
      // const message = 'Hello from child!';
      this.messageEvent.emit();
    }

}
