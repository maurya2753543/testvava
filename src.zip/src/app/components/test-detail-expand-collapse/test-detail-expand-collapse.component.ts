import { Component } from '@angular/core';
import { SharedService } from 'src/app/services/shared.service';
import { faChevronsUp, faChevronsDown } from '@fortawesome/pro-solid-svg-icons'

@Component({
  selector: 'app-test-detail-expand-collapse',
  templateUrl: './test-detail-expand-collapse.component.html',
  styleUrls: ['./test-detail-expand-collapse.component.scss']
})
export class TestDetailExpandCollapseComponent {
  faChevronsUp = faChevronsUp
  faChevronsDown = faChevronsDown
  expandIcon = faChevronsUp;
  splitAreaSize1 = 50;
  splitAreaSize2 = 50;
  splitAreaSize: any = []
  toggledIcon: boolean = false;
  
  constructor(private sharedService: SharedService) {
  }
  previousRow() {
    // this.sharedService.setPreNextValue('');
    this.sharedService.setPreNextValue('Previous');
  }

  nextRow() {
    this.sharedService.setPreNextValue('Next');
  }
  public toggleExpandIcon(toggledIcon: boolean) {
         this.splitAreaSize = {"gridSize": 50, "detailSize": 50}
        
        if(toggledIcon === true) {
          this.expandIcon = faChevronsUp; 
          // this.splitAreaSize = {"gridSize": 50, "detailSize": 50}
        } else {
          this.expandIcon = faChevronsDown; 
          this.splitAreaSize = {"gridSize": 20, "detailSize": 80}
        }
        this.sharedService.setSizetValue(this.splitAreaSize);
        this.toggledIcon = !toggledIcon;
    
      }
}
