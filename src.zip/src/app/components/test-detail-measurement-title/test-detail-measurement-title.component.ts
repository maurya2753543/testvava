import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { SharedService } from 'src/app/services/shared.service';
import { faChevronsUp, faChevronsDown } from '@fortawesome/pro-solid-svg-icons'

@Component({
  selector: 'app-test-detail-measurement-title',
  templateUrl: './test-detail-measurement-title.component.html',
  styleUrls: ['./test-detail-measurement-title.component.scss']
})
export class TestDetailMeasurementTitleComponent implements OnInit {

  @Input()
  detailData: Array<any> = [];
  statusColor: string = ''
  icon: string = ''

  constructor(private sharedService: SharedService) {
  }

  ngOnInit(): void {

    // this.statusColor = this.detailData[0].tests[0].results.status  === 'fail'?  'red' : 'green';
    if (this.detailData[0].tests[0].results.status === 'fail') {
      this.statusColor = "red"
      this.icon = "fa-circle-xmark"
    } else  {
      this.statusColor = "green"
      this.icon = "fa-circle-check"
    }
    if (this.detailData[0].tests[0].results.status === 'none') {
      this.statusColor = "brown"
      this.icon = "fa-solid fa-circle-question"
    } else{


    }
  }






}
