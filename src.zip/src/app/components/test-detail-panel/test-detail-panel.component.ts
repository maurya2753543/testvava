import { Component, EventEmitter, Input, Output } from '@angular/core';
import {
    faUp,
    faDown
  } from '@fortawesome/pro-solid-svg-icons'
import { TestDetailTabsComponent } from '../test-detail-tabs/test-detail-tabs.component';
import { TestDetailService } from 'src/app/services/test-detail.service';
import { DarkModeService } from 'src/app/services/darkMode.service';

@Component({
  selector: 'app-test-detail-panel',
  templateUrl: './test-detail-panel.component.html',
  styleUrls: ['./test-detail-panel.component.scss']
})
export class TestDetailPanelComponent {

  constructor(private TestDetailService: TestDetailService, private DarkModeService: DarkModeService) { }
    faUp = faUp
    faDown = faDown
    detailData: any
    hideDetail: boolean = true;
    @Input() selectedRow: any
  
    DarkThemesApply :any
    
    sidebyside = true;
    myDirection:any = 'vertical';

    ngOnInit(): void {
      this.detailData = this.TestDetailService.getMeasurementData()
      this.DarkModeService.isDarkThemesActiveSubject$.subscribe(value => {
        this.DarkThemesApply=value

      })
  }
    setSplit() {
        this.sidebyside = !this.sidebyside;
        if (this.sidebyside) {
            this.myDirection = 'vertical';
            
        } else {
            this.myDirection = 'horizontal';
           
        }
    }

      upddateRowCheckedData(selectedRow: any) {
        //debugger;
        console.log( ">>>>>>>", this.detailData, selectedRow )
        this.detailData[0].tests[0].label = selectedRow.Test;
        this.selectedRow = selectedRow;
        this.hideDetail = false;
      }





}
