import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestDetailPanelComponent } from './test-detail-panel.component';

describe('TestDetailPanelComponent', () => {
  let component: TestDetailPanelComponent;
  let fixture: ComponentFixture<TestDetailPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestDetailPanelComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestDetailPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
