import { Component, OnInit } from '@angular/core';

 

@Component({
  selector: 'app-theme',
  template: '',
  styleUrls: ['./theme.component.scss']
})
export class Themes  {

}
