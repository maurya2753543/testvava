import { Component } from '@angular/core';
// import {FormControl} from '@angular/forms';
// import {ThemePalette} from '@angular/material/core';

@Component({
  selector: 'app-settings-panel',
  templateUrl: './settings-panel.component.html',
  styleUrls: ['./settings-panel.component.scss']
})
export class SettingsPanelComponent {
  selectedLanguage: any = "English";
  selectedUnit: any = "Feets";
  languages: string[] = [
    'English',
    'Spanish',
    'French',
    'German',
    'Italian',
    'Portuguese',
    'Russian',
    'Chinese',
    'Japanese',
    'Korean'
  ];

  Units: string[] = ["Feets", "Meters", "Kilometer"]
}
