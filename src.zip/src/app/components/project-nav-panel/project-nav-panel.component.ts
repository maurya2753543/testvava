import { Component, ElementRef, OnInit, ViewChild, Renderer2 } from '@angular/core';
import { FlatTreeControl, NestedTreeControl } from '@angular/cdk/tree';
import { MatTree, MatTreeFlatDataSource, MatTreeFlattener, MatTreeNestedDataSource, MatTreeNode, MatTreeNodeToggle } from '@angular/material/tree';
import { ProjectsService } from 'src/app/services/projects.service';
import { MatBadgeModule } from '@angular/material/badge';
import { SharedService } from 'src/app/services/shared.service';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { TodoItemFlatNode, TodoItemNode, TreeDataService } from 'src/app/services/tree-data.service';
import { SelectionModel } from '@angular/cdk/collections';
import { ConfirmationDialogComponent } from '../confirmation-dialog/confirmation-dialog.component';
import { MatDialog } from '@angular/material/dialog';

interface ProjectNode {
  name: string;
  iconname?: string;
  children?: ProjectNode[];
}

interface TreeNode {
  name: string;
  children?: TreeNode[];
  isEditing?: boolean;
  newItem?: string;
  rev?: string;
}

//   const TREE_DATA: ProjectNode[] = [ ];

import { DarkModeService } from 'src/app/services/darkMode.service';

@Component({
  selector: 'app-project-nav-panel',
  templateUrl: './project-nav-panel.component.html',
  styleUrls: ['./project-nav-panel.component.scss']
})
export class ProjectNavPanelComponent implements OnInit {

  // treeControl = new NestedTreeControl<ProjectNode>(node => node.children);

  // dataSource = new MatTreeNestedDataSource<ProjectNode>();
  toolbarService: any;
  /* Drag and drop */
  dragNode: any;
  dragNodeExpandOverWaitTimeMs = 300;
  dragNodeExpandOverNode: any;
  dragNodeExpandOverTime?: any;
  dragNodeExpandOverArea?: any;
  activeNode: any;
  disabledAdd: boolean = false;
  addProjectNodeTemplate: boolean = false;
  editedValue: string = ''
  projects: any;
  @ViewChild('myProjectNameField')
  myProjectNameFieldInput!: ElementRef;

  @ViewChild('saveProjectButton')
  saveProjectButton!: any;

  @ViewChild(MatTree)
  tree!: MatTree<any>;
  newProject: boolean = false;
  public selectedData: any[] = [];
  public dark: any;
  elementRef: any;
  treeData: any
  nodeId: any;
  breadcrumbs: any[] = []
  node: any
  // Dark themes

  DarkThemesApply: any
  constructor(private projectsService: ProjectsService,
    private sharedService: SharedService,

    private TreeDataService: TreeDataService,
    private dialog: MatDialog, private renderer: Renderer2, public darkModeService: DarkModeService) {
    // this.dataSource.data = this.projectsService.getProjectsTree();
    // Dark themes
    this.darkModeService.isDarkThemesActiveSubject$.subscribe(value => {
      this.DarkThemesApply = value

    })


    this.treeFlattener = new MatTreeFlattener(
      this.transformer,
      this.getLevel,
      this.isExpandable,
      this.getChildren,
    );
    this.treeControl = new FlatTreeControl<TodoItemFlatNode>(this.getLevel, this.isExpandable);
    this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
    TreeDataService.dataChange.subscribe(data => {
      this.dataSource.data = data;
    });
  }

  ngOnInit() {
    this.selectedData = this.sharedService.getSelectedData();
    this.sharedService.valueidSubject$.subscribe((value: any) => {
      const nodeOldElement = this.getTreeNodeByKey(this.nodeId);
      nodeOldElement?.nativeElement.setAttribute('class', 'mat-tree-node cdk-tree-node ng-star-inserted')
      this.nodeId = value.value;
      this.buildBreadScrumbsFromTree()
      const nodeElement = this.getTreeNodeByKey(this.nodeId);
      if (nodeElement) {
        nodeElement.nativeElement.setAttribute('class', 'mat-tree-node cdk-tree-node ng-star-inserted selected-background-highlight');
      }
      if (!value.nodeClicked) {
        for (const node of this.breadcrumbs) {
          if (node.id === this.nodeId) {
            this.activeNode = node;
            this.node = node;
            this.triggerNodeClick(this.nodeId);
            return
          }
        }
      }


    })
  }


  triggerNodeClick(nodeId: string): void {
    const nodeElement = this.getTreeNodeByKey(nodeId);
    if (nodeElement) {
      this.nodeClicked(this.node);
      nodeElement.nativeElement.setAttribute('class', 'mat-tree-node cdk-tree-node ng-star-inserted selected-background-highlight');
    }

  }

  nodeClicked(node: any) {
    if (!this.treeControl.isExpanded(node)) {
      let parent = null;
      let index = this.treeControl.dataNodes.findIndex((n) => n.id === node.id);
      parent = this.treeControl.dataNodes[index];

      if (parent) {
        this.treeControl.collapseDescendants(parent);
        this.treeControl.expand(parent);
      } else {
        this.treeControl.collapseAll()
      }
      this.treeControl.expand(node);
    }
  }

  // Get the DOM element of a node in the mat-tree based on its key
  getTreeNodeByKey(key: string): ElementRef | null {
    const treeNodes = Array.from(document.querySelectorAll('.mat-tree-node')) as Element[];
    for (const treeNode of treeNodes) {
      const nodeKey = treeNode.getAttribute('data-key');
      if (nodeKey === key) {
        return new ElementRef(treeNode);
      }
    }
    return null;
  }

  addNewProjectClick(message: any) {
    this.TreeDataService.createProject(message).subscribe((res: any) => {
      this.TreeDataService.initialize()
    })
    this.newProject = false;
    this.addProjectNodeTemplate = false
  }

  newSubProject() {
    console.log($localize`new sub Project`);
  }

  newFolder() {
    console.log($localize`new folder`);
  }

  logNode(node: any) {

  }

  activeNodeClicked(node: any, nodeClicked?: boolean) {
    nodeClicked = nodeClicked !== undefined ? nodeClicked : true
    this.activeNode = node;
    this.sharedService.setIdValue(node.id, nodeClicked);
    this.buildBreadScrumbsFromTree()
  }

  dragHover(node: any) {
    // // debugger
  }

  dragHoverEnd() {
    // // debugger
  }
  dragStart() {
    // // debugger
  }
  drop(params: any) {
    // // debugger
  }


  handleDragOver(event: any, node: any) {
    event.preventDefault();
    // Handle node expand
    if (this.dragNodeExpandOverNode && node === this.dragNodeExpandOverNode) {
      if ((Date.now() - this.dragNodeExpandOverTime) > this.dragNodeExpandOverWaitTimeMs) {
        if (!this.treeControl.isExpanded(node)) {
          this.treeControl.expand(node);
          //this.cd.detectChanges();
        }
      }
    } else {
      this.dragNodeExpandOverNode = node;
      this.dragNodeExpandOverTime = new Date().getTime();
    }

    // Handle drag area
    const percentageY = event.offsetY / event.target.clientHeight;
    if (0 <= percentageY && percentageY <= 0.25) {
      this.dragNodeExpandOverArea = 1;
    } else if (1 >= percentageY && percentageY >= 0.75) {
      this.dragNodeExpandOverArea = -1;
    } else {
      this.dragNodeExpandOverArea = 0;
    }
  }


  handleDrop(event: any, node: any) {
    // // debugger
  }

  handleDragEnd(event: any) {
    this.dragNode = null;
    this.dragNodeExpandOverNode = null;
    this.dragNodeExpandOverTime = 0;
    this.dragNodeExpandOverArea = NaN;
    event.preventDefault();
  }

  dropHandler(event: any) {
    event.preventDefault();
    const payload = event.dataTransfer.getData('text/plain');
    const data = JSON.parse(payload);
    console.log(data)
  }


  // onGridDropped(event: CdkDragDrop<any>){
  //   console.log("called")
  //   const gridElemennt = event.name.element.nativeElement as HTMLElement;
  //   const draggedRow = event.name.data.row;
  //   console.log(draggedRow)
  //   console.log(gridElemennt)
  //  }


  onDragOver(event: any) {
    var dragSupported = event.dataTransfer.length;
    if (dragSupported) {
      event.dataTransfer.dropEffect = 'move';
    }
    event.preventDefault();
  }


  ////////////////////////////////////////////Mat-tree- with add child and project feature////////////////////////////////////////////////////////////

  /** Map from flat node to nested node. This helps us finding the nested node to be modified */
  flatNodeMap = new Map<TodoItemFlatNode, TodoItemNode>();

  /** Map from nested node to flattened node. This helps us to keep the same object for selection */
  nestedNodeMap = new Map<TodoItemNode, TodoItemFlatNode>();

  /** A selected parent node to be inserted */
  selectedParent: TodoItemFlatNode | null = null;

  /** The new item's name */
  newItemName = '';

  treeControl: FlatTreeControl<TodoItemFlatNode>;

  treeFlattener: MatTreeFlattener<TodoItemNode, TodoItemFlatNode>;

  dataSource: MatTreeFlatDataSource<TodoItemNode, TodoItemFlatNode>;

  /** The selection for checklist */
  checklistSelection = new SelectionModel<TodoItemFlatNode>(true /* multiple */);

  //  constructor(private TreeDataService: ChecklistDatabase) {

  //  }
  getLevel = (node: TodoItemFlatNode) => node.level;

  isExpandable = (node: TodoItemFlatNode) => node.expandable;

  getChildren = (node: TodoItemNode): TodoItemNode[] => node.children;

  hasChild = (_: number, _nodeData: TodoItemFlatNode) => _nodeData.expandable;

  hasNoContent = (_: number, _nodeData: TodoItemFlatNode) => _nodeData.name === '';

  /**
   * Transformer to convert nested node to flat node. Record the nodes in maps for later use.
   */
  transformer = (node: TodoItemNode, level: number) => {
    const existingNode = this.nestedNodeMap.get(node);
    const flatNode =
      existingNode && existingNode.name === node.name ? existingNode : new TodoItemFlatNode();
    flatNode.name = node.name;
    flatNode.id = node.id;
    flatNode.level = level;
    flatNode.expandable = true;
    flatNode.children = node.children;
    flatNode.rev = node.rev;
    flatNode.parent = node.parent;
    flatNode.projectId = node.projectId;
    this.flatNodeMap.set(flatNode, node);
    this.nestedNodeMap.set(node, flatNode);
    return flatNode;
  };

  /** Whether all the descendants of the node are selected. */
  descendantsAllSelected(node: TodoItemFlatNode): boolean {
    const descendants = this.treeControl.getDescendants(node);
    const descAllSelected =
      descendants.length > 0 &&
      descendants.every(child => {
        return this.checklistSelection.isSelected(child);
      });
    return descAllSelected;
  }

  /** Whether part of the descendants are selected */
  descendantsPartiallySelected(node: TodoItemFlatNode): boolean {
    const descendants = this.treeControl.getDescendants(node);
    const result = descendants.some(child => this.checklistSelection.isSelected(child));
    return result && !this.descendantsAllSelected(node);
  }

  /** Toggle the to-do item selection. Select/deselect all the descendants node */
  todoItemSelectionToggle(node: TodoItemFlatNode): void {
    this.checklistSelection.toggle(node);
    const descendants = this.treeControl.getDescendants(node);
    this.checklistSelection.isSelected(node)
      ? this.checklistSelection.select(...descendants)
      : this.checklistSelection.deselect(...descendants);

    // Force update for the parent
    descendants.forEach(child => this.checklistSelection.isSelected(child));
    this.checkAllParentsSelection(node);
  }

  /** Toggle a leaf to-do item selection. Check all the parents to see if they changed */
  todoLeafItemSelectionToggle(node: TodoItemFlatNode): void {
    this.checklistSelection.toggle(node);
    this.checkAllParentsSelection(node);
  }

  /* Checks all the parents when a leaf node is selected/unselected */
  checkAllParentsSelection(node: TodoItemFlatNode): void {
    let parent: TodoItemFlatNode | null = this.getParentNode(node);
    while (parent) {
      this.checkRootNodeSelection(parent);
      parent = this.getParentNode(parent);
    }
  }

  /** Check root node checked state and change it accordingly */
  checkRootNodeSelection(node: TodoItemFlatNode): void {
    const nodeSelected = this.checklistSelection.isSelected(node);
    const descendants = this.treeControl.getDescendants(node);
    const descAllSelected =
      descendants.length > 0 &&
      descendants.every(child => {
        return this.checklistSelection.isSelected(child);
      });
    if (nodeSelected && !descAllSelected) {
      this.checklistSelection.deselect(node);
    } else if (!nodeSelected && descAllSelected) {
      this.checklistSelection.select(node);
    }
  }

  /* Get the parent node of a node */
  getParentNode(node: TodoItemFlatNode): TodoItemFlatNode | null {
    const currentLevel = this.getLevel(node);

    if (currentLevel < 1) {
      return null;
    }

    const startIndex = this.treeControl.dataNodes.indexOf(node) - 1;

    for (let i = startIndex; i >= 0; i--) {
      const currentNode = this.treeControl.dataNodes[i];

      if (this.getLevel(currentNode) < currentLevel) {
        return currentNode;
      }
    }
    return null;
  }

  /** Select the category so we can insert the new item. */
  addNewItem(node: TodoItemFlatNode) {
    const parentNode = this.flatNodeMap.get(node);
    this.TreeDataService.removeInsert(this.activeNode)
    this.TreeDataService.insertItem(parentNode!, '');
    this.treeControl.expand(node);
    this.disabledAdd = true
  }

  /** Save the node to database */
  saveNode(node: TodoItemFlatNode, itemValue: string) {
    const nestedNode = this.flatNodeMap.get(node);
    // 
    this.TreeDataService.addFolderProject(this.activeNode.id, this.activeNode.projectId, itemValue).subscribe(result => {
      if (result.ok) {
        this.TreeDataService.updateItem(nestedNode!, { [itemValue]: [''] }, this.activeNode.id, this.activeNode.projectId, result.id);
      }
    })
    this.disabledAdd = false
  }

  ////////trigger save on enter ///////////

  triggerProjectSave() {
    console.log('this.saveProjectButton.nativeElement', this.saveProjectButton._elementRef.nativeElement);
    setTimeout(() => this.saveProjectButton._elementRef.nativeElement.click());
  }

  triggerNodeSave(node: any, item: any) {
    this.saveNode(node, item);
  }

  handleChildMessage() {
    this.newProject = true;
    this.addProjectNodeTemplate = true;

    setTimeout(() => this.myProjectNameFieldInput.nativeElement.focus());
  }

  isEditing = false;
  editValue: string = '';

  editNodeRecursive(nodes: TreeNode[] | undefined, nodeToEdit: TreeNode, editValue: string) {
    if (nodes)
      for (let i = 0; i < this.dataSource.data.length; i++) {
        if (this.dataSource.data[i].name === nodeToEdit.name) {
          this.dataSource.data[i].name = editValue;
          return;
        }

        this.dataSource.data = [...this.dataSource.data]
      }
  }
  startEditing(node: TreeNode) {
    node.isEditing = true;
  }

  stopEditing(node: TreeNode, newName: any) {
    node.name = newName.target.value;
    node.isEditing = false;
  }

  cancelNode(activeNode?: any) {
    this.disabledAdd = false;
    this.addProjectNodeTemplate = false;
    if (activeNode) {
      this.TreeDataService.removeInsert(activeNode);
    }
  }
  deleteNode(node: TreeNode): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '250px'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        if (result === true) {
          const data = this.dataSource.data;
          const index = this.deleteNodeRecursive(data, node);
          if (index !== -1) {
            this.dataSource.data = [...data]; // Trigger update in the data source
            console.log(`Deleted node index: ${index}`);
          }
        }
        // Proceed with deletion
        // Delete the node from the data source or update it as desired
      } else {
        this.dialog.closeAll();
      }
    });
  }

  private deleteNodeRecursive(nodes: TreeNode[] | undefined, nodeToDelete: TreeNode): number {

    let deletedIndex = -1;

    if (nodes) {
      for (let i = 0; i < nodes.length; i++) {
        if (nodes[i].name === nodeToDelete.name) {
          nodes.splice(i, 1);
          deletedIndex = i;
          this.TreeDataService.deleteProject(nodeToDelete).subscribe(res => {
            // Perform any additional actions after successful deletion
          })
          break;
        }
        if (nodes[i].children) {
          const index = this.deleteNodeRecursive(nodes[i].children, nodeToDelete);
          if (index !== -1) {
            deletedIndex = index;
            break;
          }
        }
      }
    }

    return deletedIndex;
  }

  getBreadcrumbs(tree: any) {
    const breadCrumbId = this.nodeId;
    const breadcrumbs: any[] = [];

    function findItem(node: any) {

      if (node.id === breadCrumbId) {
        // breadcrumbs.push({'name': node.name, 'id': node.id});
        breadcrumbs.push({ 'name': node.name, 'id': node.id, "expandable": true, "children": node.children, "level": node.level });
        return true;
      }

      if (node.children) {
        for (const child of node.children) {
          if (findItem(child)) {
            breadcrumbs.unshift({ 'name': node.name, 'id': node.id, "expandable": true, "children": node.children, "level": node.level });
            return true;
          }
        }
      }

      return false;
    }

    for (const node of tree) {
      if (findItem(node)) {
        break;
      }
    }

    return breadcrumbs;
  }

  buildBreadScrumbsFromTree() {
    this.TreeDataService.getProjectChildren().subscribe((treeData: any) => {
      this.treeData = treeData;
      // this.dataSource.data = treeData;
      this.breadcrumbs = this.getBreadcrumbs(treeData);
      this.sharedService.setBreadcrumbsValue(this.breadcrumbs);

    })
  }

}
