import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestDetailMeasurementInfoComponent } from './test-detail-measurement-info.component';

describe('TestDetailMeasurementInfoComponent', () => {
  let component: TestDetailMeasurementInfoComponent;
  let fixture: ComponentFixture<TestDetailMeasurementInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestDetailMeasurementInfoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestDetailMeasurementInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
