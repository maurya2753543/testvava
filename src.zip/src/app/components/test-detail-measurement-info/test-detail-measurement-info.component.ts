import { Component, Input } from '@angular/core';


@Component({
  selector: 'app-test-detail-measurement-info',
  templateUrl: './test-detail-measurement-info.component.html',
  styleUrls: ['./test-detail-measurement-info.component.scss']
})
export class TestDetailMeasurementInfoComponent {
  @Input() detailData: Array<any>;
//isDarkThemes logic
@Input() DarkThemesApply: any;




}
