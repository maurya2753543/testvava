import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/app/services/shared.service';
import { ProjectsService } from 'src/app/services/projects.service';
import {
  faCaretRight,
  faCircleCheck,
  faFileChartColumn,
  faFileExport,
  faFloppyDisk,
  faFloppyDiskPen,
  faFolderOpen,
  faImage,
  faQuestion,
  faXmarkCircle,
  faCloudArrowDown,
  faPenToSquare,
  faUsbDrive,
  faFileImport,
  faEllipsis,
  faTruckMoving,
  faTrash,
} from '@fortawesome/pro-solid-svg-icons';
import { Papa } from 'ngx-papaparse';
import { DarkModeService } from 'src/app/services/darkMode.service';

@Component({
  selector: 'app-project-info-panel',
  templateUrl: './project-info-panel.component.html',
  styleUrls: ['./project-info-panel.component.scss'],
})
export class ProjectInfoPanelComponent implements OnInit {
  // set csv data
  rowDataTable : any
  // Dark themes
  DarkThemesApply :any
  constructor(private sharedService: SharedService , private papa: Papa ,
     public darkModeService: DarkModeService
      , public ProjData: ProjectsService ) {

        this.darkModeService.isDarkThemesActiveSubject$.subscribe(value => {
          this.DarkThemesApply=value

        })
        this.rowDataTable = this.ProjData.getProjectData();


  }

  faCaretRight = faCaretRight;
  faCircleCheck = faCircleCheck;
  faFolderOpen = faFolderOpen;
  faFloppyDisk = faFloppyDisk;
  faFloppyDiskPen = faFloppyDiskPen;
  faFileExport = faFileExport;
  faFileChartColumn = faFileChartColumn;
  faHelpQuestion = faQuestion;
  faImage = faImage;
  faXMark = faXmarkCircle;
  faEllipsis = faEllipsis;
  menuHeader: any;
  faCloudArrowDown = faCloudArrowDown;
  faPenToSquare = faPenToSquare;
  faUsbDrive = faUsbDrive;
  faFileImport = faFileImport;

  faTruckMoving = faTruckMoving;
  faTrash = faTrash;
  selectedFile: any;
  importRow: any;

  activeProject = 'Project Alpha';
  // activeProjectPath = [ 'Rack 2', 'Panel 4', 'label 9']

  // activeProjectPath = [
  //   { name: 'Project Alpha', alias: 'Project' },
  //   { name: 'Rack 2', alias: 'Rack' },
  //   { name: 'Panel 4', alias: 'Panel' },
  //   { name: 'label 9', alias: 'Connector' },
  // ];

  // activeProjectPath = [];
  
   activeProjectPaths: any[] = [];
  ngOnInit(): void {
    this.darkModeService.isDarkThemesActiveSubject$.subscribe(value => {
      this.DarkThemesApply=value

    })
    this.sharedService.valueBreadcrumbsSubject$.subscribe(value => {
   this.menuHeader = value;
   this.activeProjectPaths = [];
   this.menuHeader.forEach((element: any, index: any) => {
   this.activeProjectPaths.push({ alias: `Level ${index}`, name: element.name, id: element.id });
  });


        // Handle the value update in the grand-grand-grandparent component
      });
  }

  breadCrumb(id: string) {
    this.sharedService.setIdValue(id, false);
  }
// export csv logic
exportToCSV() {

  const csv = this.papa.unparse(this.rowDataTable);
  debugger

  const blob = new Blob([csv], { type: 'text/csv' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
   // Set a custom filename (e.g., "custom_filename.csv")
   const filename = 'V_ReporterData.csv';
   a.setAttribute('download', filename);
  a.click();
  window.URL.revokeObjectURL(url);
  a.remove();
}



// export csv logic end


    // for the multiple file select for import

    onFileSelected(event: Event) {
      const input = event.target as HTMLInputElement;
      if (input && input.files && input.files.length) {
        for (var i = 0; i < input.files.length; i++) {
          console.log(input.files[i], 'how are select ++');
          // this.selectedFile = input.files[0];
          console.log(this.selectedFile, 'how are select ++');
          const reader = new FileReader();
          reader.onload = (e) => {
            const result = reader.result;
            const jsonObject = result ? JSON.parse(result.toString()) : [];
            this.importRow = jsonObject;
            this.sharedService.setImportFileData(this.importRow);
          };
          reader.readAsText(input.files[i]);
        }
      }
    }
}
