import { Component, ViewChild , OnInit } from '@angular/core';
import { faBars, faSliders, faDiagramProject, faTablets, faListCheck } from '@fortawesome/free-solid-svg-icons'
import { MatDrawer} from '@angular/material/sidenav'
import { LayoutService} from '../../services/layout.service'
import { IconDefinition} from '@fortawesome/fontawesome-svg-core'
import { CustomSideBarComponent } from '../custom-side-bar/custom-side-bar.component';
import { TestGridPanelComponent } from '../test-grid-panel/test-grid-panel.component';
import { DarkModeService } from 'src/app/services/darkMode.service';

@Component({
  selector: 'app-nav-panel',
  templateUrl: './nav-panel.component.html',
  styleUrls: ['./nav-panel.component.scss']
})
export class NavPanelComponent implements OnInit {
    @ViewChild('menuDrawer') menuDrawer!: MatDrawer
    @ViewChild('subMenuDrawer') subMenuDrawer!: MatDrawer
    @ViewChild(TestGridPanelComponent)GridChild1!: TestGridPanelComponent;
    @ViewChild(CustomSideBarComponent) CustomSideBarChild!: CustomSideBarComponent;

  showNavPanel = true
  showListView = false
  disabled = false
  expanded = false
  markersExpanded = false
  currentMenu = "Project"
  faBars = faBars
  faDiagramProject= faDiagramProject
  faTableRows = faTablets
  faSliders = faSliders
  settingLocaleString = $localize`Settings`
  projectLocaleString = $localize`Project`
  ControlGridColLocaleString = $localize`Grid Columns`
  ExpandToolTipLocaleString = $localize`Expand Tools Menu`

  // Dark themes
  DarkThemesApply :any

  menuItems: { label: string, icon: IconDefinition, tooltip: string }[] =
    [
      {
        label: this.projectLocaleString,
        icon: faDiagramProject,
        tooltip: this.projectLocaleString
      }, {
        label: this.settingLocaleString,
        icon: faSliders,
        tooltip: this.settingLocaleString
      }, {
        label: this.ControlGridColLocaleString,
        icon: faListCheck,
        tooltip: this.ControlGridColLocaleString
      }
    ]

    constructor(private layoutService: LayoutService  ,  public darkModeService: DarkModeService) {

      this.darkModeService.isDarkThemesActiveSubject$.subscribe(value => {
        this.DarkThemesApply=value

      })
      }
      ngOnInit(): void {
        // debugger

        this.darkModeService.isDarkThemesActiveSubject$.subscribe(value => {
          this.DarkThemesApply=value

        })
      }

    public toggleSubMenu(subMenu: string) {
        if (this.currentMenu === subMenu) {
          this.currentMenu = ''
          return
        }
        this.currentMenu = subMenu
      }

      refresh() {
        this.layoutService.refreshLayout()
        this.darkModeService.isDarkThemesActiveSubject$.subscribe(value => {
          this.DarkThemesApply=value

        })

      }
}
