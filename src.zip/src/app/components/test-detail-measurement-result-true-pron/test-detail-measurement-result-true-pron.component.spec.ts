import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestDetailMeasurementResultTruePronComponent } from './test-detail-measurement-result-true-pron.component';

describe('TestDetailMeasurementResultTruePronComponent', () => {
  let component: TestDetailMeasurementResultTruePronComponent;
  let fixture: ComponentFixture<TestDetailMeasurementResultTruePronComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestDetailMeasurementResultTruePronComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestDetailMeasurementResultTruePronComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
