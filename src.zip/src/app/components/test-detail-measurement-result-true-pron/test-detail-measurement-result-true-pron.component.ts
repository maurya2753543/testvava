import { Component, DebugElement, Input, OnInit } from '@angular/core';
import { DarkModeService } from 'src/app/services/darkMode.service';

@Component({
  selector: 'app-test-detail-measurement-result-true-pron',
  templateUrl: './test-detail-measurement-result-true-pron.component.html',
  styleUrls: ['./test-detail-measurement-result-true-pron.component.scss']
})
export class TestDetailMeasurementResultTruePronComponent implements OnInit {


  @Input() detailData: Array<any>;
 //@Input() DarkThemesApply: any;


   DarkThemesApply :any
constructor(private DarkModeService: DarkModeService) {
  this.DarkModeService.isDarkThemesActiveSubject$.subscribe(value => {
    this.DarkThemesApply=value

  })

 }
  ngOnInit(): void {


  //   this.DarkModeService.isDarkThemesActiveSubject$.subscribe(value => {
  //     this.DarkThemesApply=value
  //     debugger
  //   })
   }
}
