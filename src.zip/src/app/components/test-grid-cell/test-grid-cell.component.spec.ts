import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestGridCellComponent } from './test-grid-cell.component';

describe('TestGridCellComponent', () => {
  let component: TestGridCellComponent;
  let fixture: ComponentFixture<TestGridCellComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestGridCellComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestGridCellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
