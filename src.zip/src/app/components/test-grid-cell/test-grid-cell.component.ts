import { Component, OnInit } from '@angular/core';
import { AgGridAngular, ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';


@Component({
  selector: 'app-test-grid-cell',
  templateUrl: './test-grid-cell.component.html',
  styleUrls: [ './test-grid-cell.component.scss']
})

export class TestGridCellComponent implements OnInit, ICellRendererAngularComp {

    value: any;
    statusColor : any;
    icon: any;
    isPass: boolean = false;


    ngOnInit(): void {

    }
    agInit(params: ICellRendererParams): void {

        this.value = params.value;

        if ( this.value === 'PASS') {
            this.statusColor="green"
            this.icon="fa-circle-check"
            this.isPass = true

        }
        if ( this.value === 'FAIL') {
            this.statusColor="red"
            this.icon="fa-circle-xmark"
            this.isPass = false
        }
        if ( this.value === 'NONE') {
          this.statusColor="gray"
          this.icon="fa-solid fa-circle-question"
          this.isPass = true
      }
    }

    refresh(params: ICellRendererParams<any, any, any>): boolean {
        return false;
    }

}
