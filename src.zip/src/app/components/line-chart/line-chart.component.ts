import { Component, OnInit, ElementRef } from '@angular/core';
import * as d3 from 'd3';
import * as d3Scale from 'd3-scale';
import * as d3Shape from 'd3-shape';
import * as d3Array from 'd3-array';
import * as d3Axis from 'd3-axis';
import { ProjectsService } from 'src/app/services/projects.service';
import { ScaleLinear } from 'd3';
import { select, zoom, ZoomBehavior, ZoomTransform, Selection } from 'd3';

@Component({
  selector: 'app-line-chart',
  templateUrl: './line-chart.component.html',
  // template: `>`,
  styleUrls: ['./line-chart.component.scss']
})
export class LineChartComponent implements OnInit {
  private chartData = [
    { date: 1, value: 10 },
    { date: 2, value: 20 },
    { date: 1, value: 15 }
  ];
  graphHeight: number = 0;
  elementHeight: number = 500;
  readonly topMargin = 10
  readonly bottomMargin = 20
  markerAValueText: any;
  markerAValue: number = 0;
  markerBValue: number = 0;
  markerBYValue: number = 0;
  markerAYValue: number = 0;
  markerBAValue: number = 0;
  markerBAValueText: any;
  markerBValueText: any;
  xScale: any
  yScale: any
  // timeScale: ScaleLinear<number, number> | undefined
  maxY1 = -Infinity;
  maxX1 = -Infinity;
  traces: any = [1, 2, 3];
  readonly markerIcon = "-14,0 14,0 14,20 0,34 -14,20"
  yCord = this.graphHeight - this.topMargin;
  constructor(private elementRef: ElementRef, private projectService: ProjectsService) {

  }

  ngOnInit() {

    this.graphHeight = this.elementHeight - (this.topMargin + this.bottomMargin)
    this.projectService.getOTDRTrace().subscribe(data => {


      const trace = data.tests[0].results.data.otdrResults.measuredResults[0].trace;
      const result: any = [];

      for (const item of trace) {
        result.push({ date: item.x, value: item.y });
      }

      this.chartData = result;

      this.createChart();
    });
  }

  private createChart() {
    const margin = { top: 20, right: 20, bottom: 30, left: 50 };
    const height = 400 - margin.top - margin.bottom;
    const chartContainer = document.getElementById('chart');
    if (chartContainer) {
      const containerWidth = chartContainer.offsetWidth;
      const width = containerWidth - margin.left - margin.right;
      // Create a zoom behavior
      const initialScale = 1;
      // const zoomBehavior: ZoomBehavior<SVGSVGElement, unknown> = zoom<SVGSVGElement, unknown>()
      //   .scaleExtent([0.5, 2])
      //   .on('zoom', handleZoom);

      const zoom = d3.zoom<SVGGElement, any>()
        .scaleExtent([0.5, 2])
        .on("zoom", handleZoom);

      // Add event listeners to zoom buttons
      d3.select("#zoomInBtn").on("click", zoomIn);
      d3.select("#zoomOutBtn").on("click", zoomOut);
      const svg = d3.select(this.elementRef.nativeElement)
        .select('#chart')
        .append('svg')
        .attr('width', width)
        .attr('height', height + margin.top + margin.bottom)
        .append('g')
        .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')');


      // Attach zoom behavior to SVG container
      svg.call(zoom);

      // Set initial scale and transform
      svg.call(zoom.transform, d3.zoomIdentity.scale(initialScale));

      // Set initial scale and transform
      // svg.call(zoom.transform, d3.zoomIdentity.scale(initialScale));
      // Apply the zoom behavior to the SVG element
      // svg.call(zoomBehavior);
      const x = this.xScale = d3.scaleLinear()
        .range([0, width])
        .domain([0, d3.max(this.chartData, d => parseFloat(d.date.toString())) as number]);

      const y = this.yScale = d3.scaleLinear()
        .range([height, 0])
        .domain([0, d3.max(this.chartData, d => parseFloat(d.value.toString())) as number]);

      const line = d3.line<{ date: number; value: number }>()
        .x(d => x(d.date))
        .y(d => y(d.value));


      svg.append('path')
        .datum(this.chartData)
        .attr("fill", "none")
        .attr("stroke", "steelblue")
        .attr("stroke-width", 1.5)
        .attr("stroke-linejoin", "round")
        .attr("stroke-linecap", "round")
        .attr("d", line);


      // Append x-axis units
      svg.append("text")
        .attr("class", "x label")
        .attr("text-anchor", "end")
        .attr("x", width / 2)
        .attr("y", height + 25)
        .text("km (kilometers)");




      // this.markerAValueText = svg.append("text")
      //   .attr("class", "x label")
      //   .attr("text-anchor", "end")
      //   .attr("x", 120)
      //   .attr("y", height + 30)
      //   .attr('fill', 'chocolate')
      //   .text(`A:` + 0);

      // this.markerBValueText = svg.append("text")
      //   .attr("class", "x label")
      //   .attr("text-anchor", "end")
      //   .attr("y", height + 30)
      //   .attr('fill', 'chocolate')
      //   .attr("x", 220)
      //   .text(`B:` + 0);

      // this.markerBAValueText = svg.append("text")
      //   .attr("class", "x label")
      //   .attr("text-anchor", "end")
      //   .attr("y", height + 30)
      //   .attr("x", 350)
      //   .attr('fill', 'chocolate')
      //   .text(`B - A:` + 0);

      // Append y-axis units
      svg.append("text")
        .attr("class", "y label")
        .attr("text-anchor", "end")
        .attr("y", -40)
        .attr("dy", ".75em")
        .attr("transform", "rotate(-90)")
        .text("dB");



      svg.append('g')
        .attr('class', 'axis axis--x')
        .attr('transform', 'translate(0,' + height + ')')
        .attr("stroke-opacity", 0.1)
        .call(d3Axis.axisBottom(x)).call((g: any) => g.select(".domain").remove())
        .call((g: any) =>
          g
            .selectAll(".tick line")
            .attr("stroke-opacity", 0.1)
            .attr("y1", -height)
        );

      svg.append('g')
        .attr('class', 'axis axis--y')
        .call(d3.axisLeft(y.copy().interpolate(d3.interpolateRound)))
        .call((g: any) => g.select(".domain").remove())
        .call((g: any) =>
          g
            .selectAll(".tick line")
            .clone()
            .attr("stroke-opacity", 0.1)
            .attr("x1", width)
        );

      const linePolygon = svg.append('g')
        .attr('transform', 'translate( 0 , 0)');

      const linePolygonB = svg.append('g')
        .attr('transform', 'translate( 0 , 0)');

      const markerGroup = linePolygon.append('g')
        .attr('class', 'marker-head')
        .attr('transform', 'translate( 0 , 0)');

      markerGroup.append('polygon')
        .attr('points', this.markerIcon)
        .attr('class', 'M3 M3-fill');

      markerGroup.append('line')
        .attr("y2", 350)
        .attr("stroke-width", 2)
        .attr("stroke", '#3548F5')
        .attr('stroke-dasharray', '5,5,2,5');

      markerGroup.append('text')
        .attr('class', 'marker-text unselectable M3')
        .text('A')
        .attr('fill', 'chocolate')
        .attr('dominant-baseline', 'middle')
        .attr('text-anchor', 'middle')
        .style('font-size', '15px');


      const markerGroupB = linePolygonB.append('g')
        .attr('class', 'marker-head')
        .attr('transform', 'translate( 0 , 0)');

      markerGroupB.append('polygon')
        .attr('points', this.markerIcon)
        .attr('class', 'M3 M3-fill');

      markerGroupB.append('line')
        .attr("y1", 0)
        .attr("y2", 350)
        .attr("stroke-width", 2)
        .attr("stroke", '#3548F5')
        .attr('stroke-dasharray', '5,5,2,5');;

      markerGroupB.append('text')
        .attr('class', 'marker-text unselectable M3')
        .text('B')
        .attr('dominant-baseline', 'middle')
        .attr('text-anchor', 'middle')
        .attr('fill', 'chocolate')
        .style('font-size', '15px');

      //   function zoomed() {
      //     g.attr("transform", d3.event.transform);
      // }
      // Zoom event handler
      function handleZoom(event: any, d: unknown) {
        // Get the current zoom transform
        const transform: ZoomTransform = event.transform;

        // Apply the zoom transform to the SVG elements you want to zoom
        svg.attr('transform', transform.toString());
      }


      // Zoom in function
      function zoomIn() {
        svg.call(zoom.scaleBy, 1.2);
      }

      // Zoom out function
      function zoomOut() {
        svg.call(zoom.scaleBy, 0.8);
      }

      const dragHandler = (selection: d3.Selection<SVGGElement, any, any, any>) =>
        d3.drag<SVGGElement, any>()
          .on('drag', (event) => {
            const chartWidth = width - margin.left - margin.right;
            const chartHeight = height - margin.top - margin.bottom;

            // Calculate the new x and y coordinates within the chart area
            let newX = event.x;
            let newY = event.y;

  
            // Constrain the x-coordinate within the chart area
            // newX = Math.max(-250, Math.min(newX, chartWidth - 250));
            if (selection.nodes()[0].textContent === 'A') {
              // this.flatness.setSpan(newX >= 0 ? newX * 2 : 0)

              this.markerAValue = this.xScale.invert(event.x);

              const desiredXA = event.x;

              // Invert the x value to obtain the corresponding data value
              const invertedXA = this.xScale.invert(desiredXA);

              // Find the closest data point to the inverted x value
              const closestDataPoint = this.chartData.reduce((closest, current) => {
                const currentX = parseFloat(current.date.toString());
                const closestX = parseFloat(closest.date.toString());
                const invertedXAValue = parseFloat(invertedXA);

                const currentDistance = Math.abs(currentX - invertedXAValue);
                const closestDistance = Math.abs(closestX - invertedXAValue);

                return currentDistance < closestDistance ? current : closest;
              });

              // Retrieve the corresponding y value from the closest data point
              const desiredAY = parseFloat(closestDataPoint.value.toString());

              this.markerAYValue = desiredAY;

              selection.attr('transform', `translate(${newX},0)`);
            } else {
              // this.markerBValue = Math.max(-250, Math.min(newX, chartWidth - 250));

              this.markerBValue = this.xScale.invert(event.x);
              const desiredXB = event.x;

              // Invert the x value to obtain the corresponding data value
              const invertedXB = this.xScale.invert(desiredXB);

              // Find the closest data point to the inverted x value
              const closestDataPoint = this.chartData.reduce((closest, current) => {
                const currentX = parseFloat(current.date.toString());
                const closestX = parseFloat(closest.date.toString());
                const invertedXBValue = parseFloat(invertedXB);

                const currentDistance = Math.abs(currentX - invertedXBValue);
                const closestDistance = Math.abs(closestX - invertedXBValue);

                return currentDistance < closestDistance ? current : closest;
              });

              // Retrieve the corresponding y value from the closest data point
              const desiredBY = parseFloat(closestDataPoint.value.toString());

              this.markerBYValue = desiredBY;

              console.log(`The y value at x=${desiredXB} is ${desiredBY}`);
              selection.attr('transform', `translate(${newX},0)`);
            }

          });

      markerGroup.call(dragHandler(markerGroup));
      markerGroupB.call(dragHandler(markerGroupB));
    }
  }
}
