import { Component, Input } from '@angular/core';
import { ProjectsService } from 'src/app/services/projects.service';
export interface ResultTableData {
  zone: string;
  scratches: string;
  defect: string;
}
const TABBLE1_DATA: ResultTableData[] = [
  { zone: 'Zone_A (0 - 25)', scratches: '  PASS', defect: 'PASS' },
  { zone: 'Zone_B (25 - 115)', scratches: 'PASS', defect: 'PASS' },
  { zone: 'Zone_C (115 - 135)', scratches: 'FAIL', defect: 'FAIL' },
  { zone: 'Zone_D (135 - 250)', scratches: 'FAIL', defect: 'FAIL' }
];
@Component({
  selector: 'app-test-measurement-inspection',
  templateUrl: './test-measurement-inspection.component.html',
  styleUrls: ['./test-measurement-inspection.component.scss']
})


export class TestMeasurementInspectionComponent {
  displayedColumns: string[] = ['zone', 'scratches', 'defect'];
  dataSource = TABBLE1_DATA;
  imageUrl: any = [];
  @Input() DarkThemesApply: any;
  // Dark themes

  // DarkThemesApply :any
  constructor(private projectsService: ProjectsService) {
  }
  ngOnInit() {
    this.projectsService.getFiberInspectionLoss().subscribe((data: any) => {
      const magData = [];
      magData.push(
        { 'atob': data.tests[0].results.data.endfaces[0].images.lowMag.fiberAndOverlaysImage.dataBase64, 'label': 'Low Magnification', "width": data.tests[0].results.data.endfaces[0].images.lowMag.fiberImage.width,
        "height": data.tests[0].results.data.endfaces[0].images.lowMag.fiberImage.height},
        { 'atob': data.tests[0].results.data.endfaces[0].images.highMag.fiberAndOverlaysImage.dataBase64, 'label': 'High Magnification', "width": data.tests[0].results.data.endfaces[0].images.highMag.fiberImage.width,
        "height":data.tests[0].results.data.endfaces[0].images.highMag.fiberImage.height});


      magData.forEach(element => {
        this.converBase64ToBinary(element);
      });
    })
  }

  converBase64ToBinary(data: any) {
    // Convert Base64 to binary data
    const binaryData = atob(data.atob);

    // Convert binary data to an ArrayBuffer
    const buffer = new ArrayBuffer(binaryData.length);
    const view = new Uint8Array(buffer);
    for (let i = 0; i < binaryData.length; i++) {
      view[i] = binaryData.charCodeAt(i);
    }

    // Convert ArrayBuffer to Blob
    const blob = new Blob([buffer], { type: 'image/png' }); // Specify the appropriate MIME type

    // Create a URL for the Blob
    this.imageUrl.push({ 'img': URL.createObjectURL(blob), 'label': data.label, "width": data.width, "height": data.height });
  }

}
