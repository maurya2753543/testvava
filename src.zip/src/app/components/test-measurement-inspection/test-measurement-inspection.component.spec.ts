import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestMeasurementInspectionComponent } from './test-measurement-inspection.component';

describe('TestMeasurementInspectionComponent', () => {
  let component: TestMeasurementInspectionComponent;
  let fixture: ComponentFixture<TestMeasurementInspectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestMeasurementInspectionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestMeasurementInspectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
