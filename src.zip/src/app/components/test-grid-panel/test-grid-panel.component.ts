import { Component, OnInit, EventEmitter, Output, ViewChild, OnDestroy } from '@angular/core';
import { TestGridCellComponent } from '../test-grid-cell/test-grid-cell.component';
import { ProjectsService } from 'src/app/services/projects.service';
import { SharedService } from 'src/app/services/shared.service';
import { DarkModeService } from 'src/app/services/darkMode.service';

import { Subscription, retry } from 'rxjs';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { MyCustomCellRendererComponent } from './MyCustomCellRendererComponent';


import {
  faCircleX,
  faCircleCheck,
  faEdit
} from '@fortawesome/pro-solid-svg-icons'
import { ColDef, GridReadyEvent, IDateFilterParams, ITextFilterParams, RowDropZoneParams, RowNode, SideBarDef, StatusPanelDef, CellValueChangedEvent, Column, ColumnApi, GridApi, ICellRendererParams, IRowNode } from 'ag-grid-community';

interface TestResultRow {
  Timestamp: string;
  Test: string;
  Location: string;
  Status: string;
  Limit: string;
  device: string;
  id: number;
}


@Component({
  selector: 'app-test-grid-panel',
  templateUrl: './test-grid-panel.component.html',
  styleUrls: ['./test-grid-panel.component.scss']
})
export class TestGridPanelComponent implements OnInit, OnDestroy {
  // @ViewChild(CustomSideBarComponent) customSidebar: CustomSideBarComponent;
  //dark thems
  isDarkThemesActive: boolean = false;

  @Output() childEvent = new EventEmitter();
  @Output() rowEvent = new EventEmitter();
  rowData: any;
  gridApi: any;
  private gridColumnApi: any;
  selectedRows: any = [];
  selectedRow: any = [];
  treeData: any = []
  faCircleX = faCircleX
  faCircleCheck = faCircleCheck
  faEdit = faEdit
  clickEventSubscription: Subscription
  public autoGroupColumnDef: ColDef = {
    minWidth: 200,
  };
  items: string[] = ['Item 1', 'Item 2', 'Item 3'];
  isVisible = false;
  selectedRowIndex: number = 0;
  list: any = [];
  // test: any
  private darkThemesubscription: Subscription;

  DarkThemesApply: any;
  constructor(private projectsService: ProjectsService,
    private sharedService: SharedService, public darkModeService: DarkModeService) {
    this.darkModeService.isDarkThemesActiveSubject$.subscribe(value => {
      this.DarkThemesApply = value

    })

    this.clickEventSubscription = this.sharedService.getClickEvent().subscribe(() => {
      // for the dark themes
      this.getSelectedRows()
    })
    // debugger
    this.sharedService.isVisibleSource.next(this.isVisible);
    // this.sharedService.columnDefs.next(this.columnDefs);
    this.sharedService.setColumnDefincation(this.columnDefs);
    // this.sharedService.setColumnDefincation(this.columnDefs);
    //  this.columnDefs = this.sharedService.getColumnDefs();
  }



  ngOnInit(): void {
    this.darkModeService.isDarkThemesActiveSubject$.subscribe(value => {
      this.DarkThemesApply = value
    })
    this.darkThemesubscription = this.darkModeService.DarkThemeEvent.subscribe(() => {
      this.handleEvent();
    });

    this.rowData = this.projectsService.getProjectData();
    this.sharedService.valuePrevNext$.subscribe(value => {
      if (value === 'Previous') {

        this.selectPreviousRow()
      } else {

        this.selectNextRow()
      }
      // Handle the value update in the grand-grand-grandparent component
    });

    //
    this.sharedService.importFileDataSubjectNext$.subscribe((value: any) => {

      // if (value.tests[0].results.status === 'none') {
      //   this.statusColor = "brown"
      //   this.icon = "fa-solid fa-circle-question"
      // } else{


      // }



      console.log("test data import", this.rowData)
      var row: TestResultRow = {
        'Test': value.tests[0].label,
        'Timestamp': value.tests[0].results.testTime,
        'Location': value.tests[0].results.Location,
        'Status': value.tests[0].results.status,
        'device': value.assetInfo.model,
        'id': 251,
        'Limit': 'NONE'
      };

      this.rowData.push(row);
      console.log("test data import1", this.rowData)

      this.gridApi.setRowData(this.rowData);

      //  this.rowData = this.rowData.push(newJsonData);
      //this.rowData.push(newJsonData[0])
    });

  }

  theme(value: string) {
    if (value) {
      document.getElementsByTagName('body')[0].classList.add(value);
    } else {
      document.getElementsByTagName('body')[0].classList.remove('dark-theme');
    }
    this.#theme = value;
  }
  #theme: string = '';
  handleEvent() {
    if (this.#theme === 'dark-theme') {
      this.isDarkThemesActive = false;
      this.#theme = '';
    } else {
      this.isDarkThemesActive = true;
      this.#theme = 'dark-theme';
    }
    this.theme(this.#theme);
  }
  ngOnDestroy() {
    this.darkThemesubscription.unsubscribe();
  }

  onItemDropped(event: CdkDragDrop<any[]>) {
    debugger
  }

  OnValueChangeTest(income: any) {
    this.gridApi.setColumnDefs(income);
  }

  columnDefs: ColDef<any>[] = [
    { field: 'Timestamp', rowDrag: true, checkboxSelection: true, headerCheckboxSelection: true, filter: 'agDateColumnFilter', filterParams: { buttons: [$localize`reset`, $localize`apply`], closeOnApply: true } as IDateFilterParams, headerTooltip: "Time Stamp", hide: false },
    { field: 'Test', headerName: $localize`Test Type`, filterParams: { buttons: ['reset', 'apply'], closeOnApply: true } as ITextFilterParams, headerTooltip: "Test Type" },
    { field: 'Location', headerName: $localize`Fiber ID`, editable: true, filterParams: { buttons: ['reset', 'apply'], closeOnApply: true } as ITextFilterParams, headerTooltip: "Fiber ID", hide: false },
    { field: 'Status', cellRenderer: TestGridCellComponent, width: 100, filterParams: { buttons: ['reset', 'apply'], closeOnApply: true } as ITextFilterParams, headerTooltip: "Status", hide: false },
    { field: 'Limit', filterParams: { buttons: ['reset', 'apply'], closeOnApply: true } as ITextFilterParams, headerTooltip: "Limit", hide: false },
    { field: 'device', headerName: $localize`Device`, filterParams: { buttons: ['reset', 'apply'], closeOnApply: true } as ITextFilterParams, headerTooltip: "Device", hide: false },
    { field: 'id', headerName: $localize`UID`, hide: true }
  ];

  defaultColDef: ColDef = { sortable: true, filter: true, resizable: true }


  // rowDragEntireRow = true
  onGridReady(params: any) {


    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    console.log(params);
    this.sharedService.setGridApi(this.gridApi);



    this.addDropZones(params);
    this.addCheckboxListener(params);
    // this.sharedService.setColumnDefs(this.columnDefs);
  }

  addCheckboxListener(params: GridReadyEvent) {
    var checkbox = document.querySelector('input[type=checkbox]')! as any;
    checkbox.addEventListener('change', function () {
      params.api.setSuppressMoveWhenRowDragging(checkbox.checked);
    });
  }
  addDropZones(params: GridReadyEvent) {
    var tileContainer = document.querySelector('.tile-container') as any;
    var dropZone: RowDropZoneParams = {
      getContainer: () => {
        return tileContainer as any;
      },
      onDragStop: (params) => {
        debugger
      },
    };
    params.api.addRowDropZone(dropZone);
  }


  getSelectedRows() {
    this.darkModeService.isDarkThemesActiveSubject$.subscribe(value => {
      this.DarkThemesApply = value

    })
    this.selectedRows = []
    this.selectedRows = (this.gridApi.getSelectedRows());
    console.log(this.selectedRows);

  }

  selectedRowsEmitEvent() {
    this.childEvent.emit(this.selectedRows);
    //  this.sharedService.valuePrevNext$ = this.selectedRow;
    // this.sharedService.setPreNextValue(this.selectedRows)
  }

  onRowSelected(event: any) {
    if (!event.node.selected) {
      return;
    }
    this.selectedRowIndex = event.rowIndex;
    // this.sharedService.valuePrevNext$ = this.selectedRow;
  }


  selectPreviousRow() {
    if (this.selectedRowIndex > 0) {
      const previousRowIndex = this.selectedRowIndex - 1;
      const previousRowNode = this.gridApi.getDisplayedRowAtIndex(previousRowIndex);

      if (previousRowNode) {
        previousRowNode.setSelected(true, true);
      }
    }
  }

  selectNextRow() {
    const model = this.gridApi.getModel();
    const maxIndex = model.getTopLevelRowCount() - 1;
    console.log('Max Index:', maxIndex);

    if (this.selectedRowIndex !== maxIndex) {
      const nextRowIndex = this.selectedRowIndex + 1;
      const nextRowNode = this.gridApi.getDisplayedRowAtIndex(nextRowIndex);

      if (nextRowNode) {
        nextRowNode.setSelected(true, true);
      }
    }
  }

  onRowClicked(event: any) {
    this.selectedRow = event.data;
    this.rowEvent.emit(this.selectedRow);
    // this.selectedRowNode = event.node;
    // Perform any other operations with the row data
  }

  public gridOptions = {
    // other grid options...
    rowDragManaged: true,
    rowDragMultiRow: true,
    cdkDrag: true,
    // getRowStyle: () => {
    //   return { 'cdkDrag': true };
    // },
    onRowDragEnd: this.onRowDragEnd.bind(this)
    // onRowDragStart: this.onRowDragStart.bind(this)

  }

  onRowDragStart(event: any) {
    const { rowNode } = event;
    const data = rowNode.data;
    const jsonData = JSON.stringify(data);
    console.log(jsonData)

    event.dataTransfer.setData('text/palin', jsonData)

  }

  onRowDragEnd(event: any) {
    debugger
    // handle the data being dragged here
  }
  onDragOver(event: any) {
    var dragSupported = event.dataTransfer.length;
    if (dragSupported) {
      event.dataTransfer.dropEffect = 'move';
    }
    event.preventDefault();
  }
  onDrop(event: any) {
    var jsonData = event.dataTransfer.getData('application/json');
    var eJsonRow = document.createElement('div');
    eJsonRow.classList.add('json-row');
    eJsonRow.innerText = jsonData;
    // var eJsonDisplay = document.querySelector('#eJsonDisplay')!;
    // eJsonDisplay.appendChild(eJsonRow);
    var data = JSON.parse(jsonData);
    console.log(jsonData)


    event.preventDefault();
  }

  /////////////////////Custom Hide and Show Coulumns in ag-grid///////////////////////

  onToggleColumnVisibility(columnsFiled: string) {
    // Set the colField value to match
    const colField = columnsFiled;
    // Find the column definition object with the matching field property
    const colDef = this.columnDefs.find((def) => def.field === colField);

    // Update the hide property of the matching column definition object
    if (colDef) {
      colDef.hide = !colDef.hide; // Or false to show the column
      this.gridApi.setColumnDefs(this.columnDefs); // Update the column definitions in the ag-Grid
      // this.SharedService.setColumnDefs(this.columnDefs);
      // this.TestGridPanelComponent.OnValueChangeTest(this.columnDefs);
    }

  }

  onCheckBoxClicked(columnsFiled: any) {
    this.onToggleColumnVisibility(columnsFiled);
  }

}
