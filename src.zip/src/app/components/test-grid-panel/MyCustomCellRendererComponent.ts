// MyCustomCellRendererComponent.ts
import { Component } from '@angular/core';
import { CdkDragDrop } from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-my-custom-cell-renderer',
  template: `
    <div cdkDrag>
      {{ params.value }}
    </div>
  `
})
export class MyCustomCellRendererComponent {
  params: any;

  agInit(params: any): void {
    this.params = params;
  }
}
