import { Component ,Input,   OnInit } from '@angular/core';
import { DarkModeService } from 'src/app/services/darkMode.service';

export interface ResultTableData1 {
  wavelength?: string;
  loss?: string;
  ref: string;
  refTimeStamp: string;
  status: string;
}
const TABBLE1_DATA: ResultTableData1[] = [
  {wavelength: '1490',  status: 'FAIL', ref: '0', refTimeStamp: '2023-04-28T'},
  {wavelength: '1577', loss: '-11.02', status: 'PASS', ref: '0', refTimeStamp: '2023-04-28T'},
];

export interface ResultTableData2 {
  wavelength?: string;
  low?: string;
  lowMarginal: string;
  highMarginal: string;
  high: string
}
const TABBLE2_DATA: ResultTableData2[] = [
  {wavelength: '1490', low: '-33', lowMarginal: '1', highMarginal: '0', high: '13'},
  {wavelength: '1577', low: '-33', lowMarginal: '1', highMarginal: '0', high: '13'}
];

@Component({
  selector: 'app-test-measurement-optical-loss',
  templateUrl: './test-measurement-optical-loss.component.html',
  styleUrls: ['./test-measurement-optical-loss.component.scss']
})
export class TestMeasurementOpticalLossComponent implements OnInit {
  displayedColumns1: string[] = ['wavelength', 'loss', 'status', 'ref', 'refTimeStamp'];
  dataSource1 = TABBLE1_DATA;

  displayedColumns2: string[] = ['wavelength', 'low', 'lowMarginal', 'highMarginal', 'high'];
  dataSource2 = TABBLE2_DATA;

 //isDarkThemes logic
//isDarkThemes logic
@Input() DarkThemesApply: any;

//  DarkThemesApply :any
//  constructor(private DarkModeService: DarkModeService) {
//   this.DarkModeService.isDarkThemesActiveSubject$.subscribe(value => {
//      this.DarkThemesApply=value

//    })

//   }
  ngOnInit() {


  //  this.DarkModeService.isDarkThemesActiveSubject$.subscribe(value => {
  //    this.DarkThemesApply=value

  //  })
 }





}
