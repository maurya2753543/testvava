import { Component, Inject, OnInit, ChangeDetectorRef } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatDialogRef } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatTableDataSource, MatTable } from '@angular/material/table';
interface UserData {
  Original: string;
  Currently: string;
  NewFiber: string;
  Location: string
}

@Component({
  selector: 'app-fiber-id-find-replace-dialog',
  templateUrl: './fiber-id-find-replace-dialog.component.html',
  styleUrls: ['./fiber-id-find-replace-dialog.component.scss']
})

export class FiberIdFindReplaceDialogComponent implements OnInit {
  findFiberId: string = "find Fiber Id";
  replace: string = "Replace with";
  showExamplesSection: boolean = false
  num: number = 1;
  searchText = '';
  showExample1: string = ''
  showButtonText: string = 'Show next example(' + this.num + '/8)'
  showDescriptionOfExm: string = 'Description of example ' + this.num;
  replaceFiberIDForm!: FormGroup;
  dataSource: MatTableDataSource<UserData>;
  displayedColumns: string[] = ['Original', 'Currently', 'NewFiber'];
  ReplacedData: any = []



  constructor(public dialogRef: MatDialogRef<FiberIdFindReplaceDialogComponent>,
    private formBuilder: FormBuilder, @Inject(MAT_DIALOG_DATA) public data: any, private changeDetectorRefs: ChangeDetectorRef) {
      this.dataSource =  new MatTableDataSource<UserData>(data);

    }

  ngOnInit() {
    this.replaceFiberIDForm = this.formBuilder.group({
      findFiberId: ['', Validators.required],
      replace: ['', Validators.required]
    });
  }


  okClick() {
    // TODO: Implement ok logic
  }

  showNextClick() {
    // let incrementedValue = this.num + 1;
    // TODO: Implement replace logic
  this.findText = "ID",
  this.replacementText = "NO."
  this.showExample1 = 'Use "Find" to replace the firct match of text "ID" with the text "No."'

  this.showExamplesSection = true
  // incrementedValue = incrementedValue + 1

  this.showDescriptionOfExm = 'Description of example ' + this.num;
  this.num = this.num + 1;
  // let buttonNum = this.num +1;
  this.showButtonText = 'Show next example(' + this.num + '/8)'
  switch(this.num) {
  case 2:
    this.findText = "ID",
    this.replacementText = "NO."
    this.showExample1 = 'Use "Find" to replace the firct match of text "ID" with the text "No."'
    break;
  case 3:
    this.findText = "***",
    this.replacementText = "Result"
    this.showExample1 = 'Use "***" to replace with the text "Result"'
    break;
  case 4:
    this.findText = "***",
    this.replacementText = "Result***6"
    this.showExample1 = 'Use "***" and "###n" to replace with the text "Result 000001" etc'
  break;
  case 5:
    this.findText = "<<<",
    this.replacementText = "XT=YZ Ltd.:"
    this.showExample1 = 'Use "<<<" to prepend text "XYZ Ltd.:"'
  break;
  case 6:
    this.findText = ">>>",
    this.replacementText = "(of Room 102)"
    this.showExample1 = 'Use ">>>" to append the text "(of Room 102)"'
  break;
  case 7:
    this.findText = "<<<",
    this.replacementText = "Task #7###2:"
    this.showExample1 = 'Use "<<<" and "###n" to prepend the text "Task #701:" etc.'
  break;
  case 8:
    this.findText = "***",
    this.replacementText = ": FiberID #7###2"
    this.showExample1 = 'Use "***" and "###n" to replace with the text "Meas 1001: FiberID #701" etc.'
  break;
  case 9:
    this.findText = "ID",
    this.replacementText = "[###6], Meas. #"
    this.showExample1 = 'Use "Find:" and "###n" to replace with the text "Number [000001], Meas. #" etc.'
    this.showButtonText = 'Restore entries';
    this.num = 1;
  break;
  default:
    this.findText = "",
    this.replacementText = ""
    this.showExample1 = ''
    break;
}
// this.num = this.num + 1;

  }

  cancelClick() {
    this.dialogRef.close();
  }

  // onSubmit() {
  //   const { Original, Currently, NewFiber } = this.replaceFiberIDForm.value;
  //   this.dataSource.data.push({ Original, Currently, NewFiber });
  //   this.dataSource._updateChangeSubscription();
  //   this.replaceFiberIDForm.reset();
  // }

  findText!: string;
  replacementText!: string;
  selectedRowIndices!: number[];

  applyReplacement() {
    this.dataSource.data.forEach((obj, index) => {
       obj.NewFiber= obj.Location.replace(this.findText, this.replacementText)
    })
  }

  onSearchKeyup(event: any) {
    const filterValue = (event.target as HTMLInputElement).value.trim().toLowerCase();
    // this.dataSource.filter = filterValue;
    this.searchText = filterValue.trim().toLowerCase();
  }

}
