import { Component, OnInit } from '@angular/core';
import * as d3 from 'd3';
import { ProjectsService } from 'src/app/services/projects.service';
import { DarkModeService } from 'src/app/services/darkMode.service';
export interface ResultTableData {
  wavelength: string;
  length: string;
}
const TABBLE1_DATA: ResultTableData[] = [
  { wavelength: '1310', length: '159.65' },
  { wavelength: '1550', length: '159.65' }
];
@Component({
  selector: 'app-test-measurement-otdr',
  templateUrl: './test-measurement-otdr.component.html',
  styleUrls: ['./test-measurement-otdr.component.scss']
})
export class TestMeasurementOtdrComponent implements OnInit {
  displayedColumns: string[] = ['wavelength', 'length'];
  dataSource = TABBLE1_DATA;
  private chartData = [
    { date: 1, value: 10 },
    { date: 2, value: 20 },
    { date: 1, value: 15 }
  ];

  // Dark themes

  DarkThemesApply: any
  constructor(private projectsService: ProjectsService, private DarkModeService: DarkModeService) {
    this.DarkModeService.isDarkThemesActiveSubject$.subscribe(value => {
      this.DarkThemesApply = value;

    })
  }
  
  ngOnInit() {

    this.DarkModeService.isDarkThemesActiveSubject$.subscribe(value => {
      this.DarkThemesApply = value

    })

    this.projectsService.getOTDRTrace().subscribe(data => {

      const trace = data.tests[0].results.data.otdrResults.measuredResults[0].trace;
      const result = [];

      for (const item of trace) {
        result.push({ date: parseFloat(item.x), value: parseFloat(item.y) });
      }

      this.chartData = result;
      this.creteCanvas();

    });

  }

  creteCanvas() {
    // Create the canvas element
    const canvas = document.getElementById('canvas') as HTMLCanvasElement;
    if (canvas) {
      canvas.width = 400;
      canvas.height = 150;


      const chartWidth = canvas.width - 40; // Adjust for padding
      const chartHeight = canvas.height - 40; // Adjust for paddin

      // Get the canvas context
      const context = canvas.getContext('2d');

      if (context) {
        // Clear the canvas
        context.clearRect(0, 0, canvas.width, canvas.height);

        const xScale = d3.scaleLinear()
          .range([20, canvas.width])
          .domain([0, d3.max(this.chartData, d => d.date) as number]);

        const yScale = d3.scaleLinear()
          .range([canvas.height - 20, 20])
          .domain([0, d3.max(this.chartData, d => d.value) as number]);


        // Draw the chart on the canvas
        context.beginPath();
        for (let i = 1; i < this.chartData.length; i++) {
          const dataPoint = this.chartData[i];
          context.lineTo(xScale(dataPoint.date), yScale(dataPoint.value));
        }
        context.strokeStyle = 'steelblue';
        context.lineWidth = 2;
        context.stroke();
        const yAxisTicks = yScale.ticks(10); // Generate the tick values for the y-axis
        const xAxisTicks = xScale.ticks(10);
        // Render the y-axis labels
        yAxisTicks.forEach(tick => {
          const y = yScale(tick); // Calculate the y-coordinate for each tick

          // Draw the tick line
          context.beginPath();
          context.moveTo(20, y);
          context.lineTo(canvas.width, y);
          context.strokeStyle = "grey";
          context.lineWidth = 0.5;
          context.stroke();

          // Draw the tick label
          context.textAlign = "end";
          context.fillText(tick.toString(), 10, y);
        });

        // Render the x-axis labels
        xAxisTicks.forEach(tick => {
          const x = xScale(tick); // Calculate the x-coordinate for each tick

          // Draw the tick line
          context.beginPath();
          context.moveTo(x, 20);
          context.lineTo(x, canvas.height - 20 + 5);
          context.strokeStyle = "grey";
          context.lineWidth = 0.5;
          context.stroke();

          // Draw the tick label
          context.textAlign = "center";
          context.fillText(tick.toString(), x, canvas.height);
        });

      }


      // Append the canvas element to the chart container
      const chartContainer = document.getElementById('chart-container') as HTMLElement;
      if (chartContainer) {
        chartContainer.appendChild(canvas);
      }
    }
  }

}
