import { Component, Input, ViewChild } from '@angular/core';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { DarkModeService } from 'src/app/services/darkMode.service';

import {
    faGear,
    faRuler,
    faRulerTriangle,
    faMobile,
    faChevronUp
  } from '@fortawesome/pro-solid-svg-icons'
  import { TestDetailPanelComponent } from '../test-detail-panel/test-detail-panel.component';
  import {ProjectInfoPanelComponent} from '../project-info-panel/project-info-panel.component'



@Component({
  selector: 'app-test-detail-tabs',
  templateUrl: './test-detail-tabs.component.html',
  styleUrls: ['./test-detail-tabs.component.scss']
})

export class TestDetailTabsComponent  {
    faGear = faGear
    faRuler = faRuler
    faRulerTriangle = faRulerTriangle
    faMobile = faMobile
    faChevronUp = faChevronUp




    @ViewChild(TestDetailPanelComponent) detailChild!: TestDetailPanelComponent;

    DarkThemesApply :any
    constructor(private DarkModeService: DarkModeService) {
      // this.DarkModeService.isDarkThemesActiveSubject$.subscribe(value => {
      //   this.DarkThemesApply=value

      // })
    }
    ngOnInit() {
      this.DarkModeService.isDarkThemesActiveSubject$.subscribe(value => {
        this.DarkThemesApply=value

      })
     }


    // @ViewChild(ProjectInfoPanelComponent) projecDataUpdate: ProjectInfoPanelComponent;


    @Input() selectedRow: any;
    updateRowData(selectedRow: any) {
      this.selectedRow = selectedRow;
      this.detailChild.upddateRowCheckedData(this.selectedRow);
      //console.log(this.projecDataUpdate ,"projecDataUpdate++++++++++++++++++++++++++++");
     //this.projecDataUpdate.upddateRowCheckedData(this.selectedRow);
    }


    // @Input() selectedRow: any;
    // updateRowDataProject(selectedRow: any) {
    //   this.selectedRow = selectedRow;
    //   this.projecDataUpdate.upddateRowCheckedData(this.selectedRow);
    // }
// dark themes logic







    expandedTabs: number[] = [];

    toggleTab(tabIndex: number): void {
      const index = this.expandedTabs.indexOf(tabIndex);
      if (index === -1) {
        this.expandedTabs.push(tabIndex);
      } else {
        this.expandedTabs.splice(index, 1);
      }
    }

    isTabExpanded(tabIndex: number): boolean {
      return this.expandedTabs.includes(tabIndex);
    }
}
