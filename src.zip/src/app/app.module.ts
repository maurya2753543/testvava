import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LandingComponent } from './components/landing/landing.component';
import { TitleBarComponent } from './components/title-bar/title-bar.component';
import { MenuBarComponent } from './components/menu-bar/menu-bar.component';
import { NavPanelComponent } from './components/nav-panel/nav-panel.component';
import { AngularSvgIconModule} from 'angular-svg-icon';
import { FontAwesomeModule, FaIconLibrary} from '@fortawesome/angular-fontawesome'
import { MatMenuModule} from '@angular/material/menu';
import { MatDividerModule } from '@angular/material/divider';
import { MatButtonModule} from '@angular/material/button';
import { MatSidenavModule} from '@angular/material/sidenav';
import { MatTooltipModule} from '@angular/material/tooltip';
import { MatTabsModule} from '@angular/material/tabs'
import { ProjectPanelComponent } from './components/project-panel/project-panel.component';
import { ProjectInfoPanelComponent } from './components/project-info-panel/project-info-panel.component';
import { TestGridPanelComponent } from './components/test-grid-panel/test-grid-panel.component';
import { TestToolbarPanelComponent } from './components/test-toolbar-panel/test-toolbar-panel.component';
import { ProjectNavPanelComponent } from './components/project-nav-panel/project-nav-panel.component';
import { AgGridModule } from 'ag-grid-angular';
import { MatTreeModule } from '@angular/material/tree';
import { MatIconModule } from '@angular/material/icon';
import { ProjectNavToolbarComponent } from './components/project-nav-toolbar/project-nav-toolbar.component';
import { SettingsPanelComponent } from './components/settings-panel/settings-panel.component';
import { StatusBarComponent } from './components/status-bar/status-bar.component';
import { ProjectsService } from './services/projects.service';
import { MatDialogModule } from '@angular/material/dialog'
import { MatNativeDateModule} from '@angular/material/core';
// import { fas } from '@fortawesome/free-solid-svg-icons';
import { ResizableModule } from "angular-resizable-element";
import { TestDetailPanelComponent } from './components/test-detail-panel/test-detail-panel.component';
import { TestDetailTabsComponent } from './components/test-detail-tabs/test-detail-tabs.component';
import { TestConfigurationComponent } from './components/test-configuration/test-configuration.component';
import { TestInstrumentComponent } from './components/test-instrument/test-instrument.component';
import { MatBadgeModule } from '@angular/material/badge';
import { AngularSplitModule } from 'angular-split';

import { MatSelectModule } from '@angular/material/select';
import { ModuleRegistry } from '@ag-grid-community/core';
// import { SideBarModule } from '@ag-grid-enterprise/side-bar';


import { ClientSideRowModelModule } from '@ag-grid-community/client-side-row-model';
import { FormsModule, ReactiveFormsModule  }   from '@angular/forms';
// import { ModuleRegistry } from '@ag-grid-community/core';
// import { ColumnsToolPanelModule } from '@ag-grid-enterprise/column-tool-panel';
// import { MenuModule } from '@ag-grid-enterprise/menu'
// import { RowGroupingModule } from '@ag-grid-enterprise/row-grouping';
// import { SetFilterModule } from '@ag-grid-enterprise/set-filter';
import { CustomSideBarComponent } from './components/custom-side-bar/custom-side-bar.component';
import { FiberIdFindReplaceDialogComponent } from './components/fiber-id-find-replace-dialog/fiber-id-find-replace-dialog.component'
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatTableModule } from '@angular/material/table';
import { HighlightPipe } from './pipes/highlight.pipe';

import { DragDropModule } from '@angular/cdk/drag-drop';
import { SharedService } from './services/shared.service';
import { GridExampleDragComponent } from './components/grid-example-drag/grid-example-drag.component';
import { TestDetailMeasurementTitleComponent } from './components/test-detail-measurement-title/test-detail-measurement-title.component';
import { TestDetailMeasurementInfoComponent } from './components/test-detail-measurement-info/test-detail-measurement-info.component';
import { TestDetailMeasurementResultOpticalPowerComponent } from './components/test-detail-measurement-result-optical-power/test-detail-measurement-result-optical-power.component';
import { TitleCaseWordPipe } from './pipes/title-case-word.pipe';
import { TestDetailMeasurementResultTruePronComponent } from './components/test-detail-measurement-result-true-pron/test-detail-measurement-result-true-pron.component';
import { MatGridListModule } from '@angular/material/grid-list';
import { TestMeasurementOpticalLossComponent } from './components/test-measurement-optical-loss/test-measurement-optical-loss.component';
import { TestMeasurementInspectionComponent } from './components/test-measurement-inspection/test-measurement-inspection.component';
import { TestMeasurementOtdrComponent } from './components/test-measurement-otdr/test-measurement-otdr.component';
import { TestDetailExpandCollapseComponent } from './components/test-detail-expand-collapse/test-detail-expand-collapse.component';
import { PassFailColorPipe } from './pipes/pass-fail-color.pipe';
import { LineChartComponent } from './components/line-chart/line-chart.component';
import { ConfirmationDialogComponent } from './components/confirmation-dialog/confirmation-dialog.component';
import { EventsTableComponent } from './components/events-table/events-table.component';
// Register the required feature modules with the Grid
// ModuleRegistry.registerModules([
//   ClientSideRowModelModule,
//   RowGroupingModule,
//   MenuModule,
//   SetFilterModule,
//   ColumnsToolPanelModule,
//   SideBarModule
// ]);


// ModuleRegistry.registerModules([
//   ClientSideRowModelModule,
//   MenuModule,
//   ColumnsToolPanelModule,
// ]);
@NgModule({
  declarations: [
    AppComponent,
    LandingComponent,
    TitleBarComponent,
    MenuBarComponent,
    NavPanelComponent,
    ProjectPanelComponent,
    ProjectInfoPanelComponent,
    TestGridPanelComponent,
    TestToolbarPanelComponent,
    ProjectNavPanelComponent,
    ProjectNavToolbarComponent,
    SettingsPanelComponent,
    StatusBarComponent,
    TestDetailPanelComponent,
    TestDetailTabsComponent,
    TestConfigurationComponent,
    TestInstrumentComponent,
    CustomSideBarComponent,
    FiberIdFindReplaceDialogComponent,
    HighlightPipe,
    GridExampleDragComponent,
    TestDetailMeasurementTitleComponent,
    TestDetailMeasurementInfoComponent,
    TestDetailMeasurementResultOpticalPowerComponent,
    TitleCaseWordPipe,
    TestDetailMeasurementResultTruePronComponent,
    TestMeasurementOpticalLossComponent,
    TestMeasurementInspectionComponent,
    TestMeasurementOtdrComponent,
    TestDetailExpandCollapseComponent,
    PassFailColorPipe,
    LineChartComponent,
    ConfirmationDialogComponent,
    EventsTableComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FontAwesomeModule,
    MatMenuModule,
    MatDividerModule,
    MatButtonModule,
    MatSidenavModule,
    MatTooltipModule,
    AgGridModule,
    MatTreeModule,
    MatIconModule,
    MatDialogModule,
    MatNativeDateModule,
    MatTabsModule,
    ResizableModule,
    MatBadgeModule,
    AngularSplitModule,
    AngularSvgIconModule.forRoot(),
    MatSelectModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatFormFieldModule,
    MatTableModule,
    DragDropModule,
    MatGridListModule

  ],
  exports: [MatSelectModule],
  providers: [ProjectsService, TestGridPanelComponent],
  bootstrap: [AppComponent],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class AppModule {
    constructor( ) {

    }
}
