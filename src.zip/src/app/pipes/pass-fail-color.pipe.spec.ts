import { PassFailColorPipe } from './pass-fail-color.pipe';

describe('PassFailColorPipe', () => {
  it('create an instance', () => {
    const pipe = new PassFailColorPipe();
    expect(pipe).toBeTruthy();
  });
});
