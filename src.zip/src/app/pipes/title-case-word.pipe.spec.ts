import { TitleCaseWordPipe } from './title-case-word.pipe';

describe('TitleCaseWordPipe', () => {
  it('create an instance', () => {
    const pipe = new TitleCaseWordPipe();
    expect(pipe).toBeTruthy();
  });
});
